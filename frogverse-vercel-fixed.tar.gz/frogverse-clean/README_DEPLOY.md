# 🚀 Деплой Frogverse

## 1. Frontend (Vercel)
1. Зарегистрируйся на [vercel.com](https://vercel.com)
2. Импортируй репозиторий, выбери папку `frontend` как root
3. Build Command: `npm run build`
4. Output Directory: `dist`
5. Пропиши переменные окружения, если нужно (например, адрес backend)
6. Деплой!

## 2. Backend (Railway)
1. Зарегистрируйся на [railway.app](https://railway.app)
2. Импортируй репозиторий, выбери папку `frogverse/backend` как root
3. Start Command: `npm install && npm run start`
4. Пропиши переменные окружения:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_BOT_USERNAME`
   - `PAYMENT_PROVIDER_TOKEN`
   - `MONGODB_URI` (лучше MongoDB Atlas)
   - `NODE_ENV=production`
5. После деплоя Railway даст тебе публичный URL backend

## 3. MongoDB Atlas
1. Зарегистрируйся на [mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas)
2. Создай free cluster, создай пользователя и базу
3. Получи строку подключения (URI) и вставь в переменные окружения backend

## 4. Mini App URL
- В BotFather укажи ссылку на фронт с Vercel: `https://your-vercel-domain.vercel.app`
- Проверь работу платежей и API

## 5. Proxy для локальной разработки
- В `frontend/vite.config.js` пропиши proxy на Railway backend

## 6. Пример .env для backend
```env
TELEGRAM_BOT_TOKEN=твой_токен_бота
TELEGRAM_BOT_USERNAME=WWNFT_BOT
PAYMENT_PROVIDER_TOKEN=твой_payment_token
MONGODB_URI=твоя_строка_подключения_Atlas
NODE_ENV=production
```

---

**Если нужен пример подключения к MongoDB Atlas или помощь с конкретным шагом — пиши!** 