import React, { useState } from 'react';
import './BattleArena.css';

const BattleArena = ({ selectedFrog, opponents, onBattleComplete }) => {
  const [selectedOpponent, setSelectedOpponent] = useState(null);
  const [battleResult, setBattleResult] = useState(null);
  const [isFighting, setIsFighting] = useState(false);

  const handleFight = async () => {
    if (!selectedOpponent) {
      alert('Выберите противника!');
      return;
    }

    setIsFighting(true);
    setBattleResult(null);

    // Симуляция битвы
    setTimeout(() => {
      const frogScore = Math.floor(Math.random() * 100) + selectedFrog.power;
      const opponentScore = Math.floor(Math.random() * 100) + selectedOpponent.power;
      
      const isWin = frogScore > opponentScore;
      const stars = isWin ? Math.floor(opponentScore / 10) : 5;
      
      const result = {
        result: isWin ? 'win' : 'loss',
        message: isWin ? 'Победа!' : 'Поражение!',
        frogScore,
        opponentScore,
        stars,
        winner: isWin ? selectedFrog : selectedOpponent
      };
      
      setBattleResult(result);
      setIsFighting(false);
      
      if (onBattleComplete) {
        onBattleComplete(result);
      }
    }, 2000);
  };

  const resetBattle = () => {
    setBattleResult(null);
    setSelectedOpponent(null);
  };

  return (
    <div className="battle-arena">
      <div className="battle-setup">
        <div className="fighter-section">
          <h3>Твой боец</h3>
          <div className="fighter-card selected-fighter">
            <div className="fighter-emoji">🐸</div>
            <div className="fighter-name">{selectedFrog.name}</div>
            <div className="fighter-stats">
              <span>Lvl {selectedFrog.level}</span>
              <span>⚔️ {selectedFrog.power}</span>
            </div>
          </div>
        </div>

        <div className="vs-section">
          <div className="vs-text">VS</div>
          <button 
            className="fight-button"
            onClick={handleFight}
            disabled={!selectedOpponent || isFighting}
          >
            {isFighting ? '⚔️ Сражаемся...' : '⚔️ СРАЖАТЬСЯ!'}
          </button>
        </div>

        <div className="fighter-section">
          <h3>Выбери противника</h3>
          <div className="opponents-grid">
            {opponents.map((opponent) => (
              <div
                key={opponent.id}
                className={`fighter-card opponent ${
                  selectedOpponent?.id === opponent.id ? 'selected' : ''
                }`}
                onClick={() => setSelectedOpponent(opponent)}
              >
                <div className="fighter-emoji">🐸</div>
                <div className="fighter-name">{opponent.name}</div>
                <div className="fighter-stats">
                  <span>Lvl {opponent.level}</span>
                  <span>⚔️ {opponent.power}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {battleResult && (
        <div className="battle-result">
          <h3>Результат битвы</h3>
          <div className={`result-card ${battleResult.result}`}>
            <div className="result-emoji">
              {battleResult.result === 'win' ? '🏆' : '💀'}
            </div>
            <div className="result-text">
              <h4>{battleResult.message}</h4>
              <div className="result-details">
                <p>Твой счет: {battleResult.frogScore}</p>
                <p>Счет противника: {battleResult.opponentScore}</p>
                <p className="stars-earned">⭐ Звезд получено: {battleResult.stars}</p>
              </div>
            </div>
          </div>
          <button className="reset-button" onClick={resetBattle}>
            Сражаться снова
          </button>
        </div>
      )}
    </div>
  );
};

export default BattleArena; 