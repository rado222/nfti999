#!/bin/bash

echo "🐸 Настройка платежей для Frogverse"
echo "=================================="

# Проверяем наличие .env файла
if [ ! -f "backend/.env" ]; then
    echo "📝 Создаем файл .env..."
    cp backend/env.example backend/.env
    echo "✅ Файл .env создан"
    echo "⚠️  Не забудь отредактировать backend/.env с твоими токенами!"
else
    echo "✅ Файл .env уже существует"
fi

# Устанавливаем зависимости
echo "📦 Устанавливаем зависимости..."
cd backend && npm install
cd ..

echo ""
echo "🎯 Следующие шаги:"
echo "1. Создай бота через @BotFather"
echo "2. Настрой платежи в @BotFather"
echo "3. Отредактируй backend/.env с твоими токенами"
echo "4. Запусти: npm run dev"
echo ""
echo "📚 Подробные инструкции в PAYMENT_SETUP.md"
echo "🧪 Тест платежей: cd backend && npm run test-payment" 