const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  telegramId: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  username: {
    type: String,
    required: false
  },
  firstName: {
    type: String,
    required: false
  },
  lastName: {
    type: String,
    required: false
  },
  referralCode: {
    type: String,
    unique: true,
    sparse: true
  },
  referredBy: {
    type: String,
    required: false
  },
  // Premium подписка
  isPremium: {
    type: Boolean,
    default: false
  },
  premiumExpiresAt: {
    type: Date,
    default: null
  },
  // Баланс звезд
  stars: {
    type: Number,
    default: 100
  },
  stats: {
    totalBattles: {
      type: Number,
      default: 0
    },
    wins: {
      type: Number,
      default: 0
    },
    losses: {
      type: Number,
      default: 0
    },
    totalStars: {
      type: Number,
      default: 100 // Начальный баланс
    },
    frogsOwned: {
      type: Number,
      default: 0
    },
    nftsMinted: {
      type: Number,
      default: 0
    },
    // Статистика слот-машины
    spins: {
      type: Number,
      default: 0
    },
    spinsWon: {
      type: Number,
      default: 0
    },
    spinsLost: {
      type: Number,
      default: 0
    },
    totalWinnings: {
      type: Number,
      default: 0
    },
    biggestWin: {
      type: Number,
      default: 0
    },
    // Статистика покупок
    totalSpent: {
      type: Number,
      default: 0
    },
    purchasesCount: {
      type: Number,
      default: 0
    }
  },
  // Статистика игры грейфер
  grabberGamesPlayed: {
    type: Number,
    default: 0
  },
  grabberTotalScore: {
    type: Number,
    default: 0
  },
  grabberHighScore: {
    type: Number,
    default: 0
  },
  grabberMaxLevel: {
    type: Number,
    default: 0
  },
  grabberGameHistory: [{
    score: Number,
    level: Number,
    starsEarned: Number,
    timestamp: {
      type: Date,
      default: Date.now
    }
  }],
  inventory: {
    frogs: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Frog'
    }],
    artifacts: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Artifact'
    }],
    nfts: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'NFT'
    }]
  },
  referralRewards: {
    totalEarned: {
      type: Number,
      default: 0
    },
    pendingRewards: {
      type: Number,
      default: 0
    },
    lastClaimed: {
      type: Date,
      default: null
    }
  },
  // История платежей
  paymentHistory: [{
    itemId: String,
    amount: Number,
    currency: String,
    stars: Number,
    date: {
      type: Date,
      default: Date.now
    },
    status: {
      type: String,
      enum: ['pending', 'completed', 'failed', 'refunded'],
      default: 'completed'
    }
  }],
  createdAt: {
    type: Date,
    default: Date.now
  },
  lastActive: {
    type: Date,
    default: Date.now
  }
});

// Метод для генерации реферального кода
userSchema.methods.generateReferralCode = function() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  this.referralCode = result;
  return this.save();
};

// Метод для обновления статистики после боя
userSchema.methods.updateBattleStats = function(isWin, starsEarned) {
  this.stats.totalBattles += 1;
  if (isWin) {
    this.stats.wins += 1;
  } else {
    this.stats.losses += 1;
  }
  this.stats.totalStars += starsEarned;
  this.lastActive = new Date();
  return this.save();
};

// Метод для обновления статистики слот-машины
userSchema.methods.updateSpinStats = function(betAmount, winAmount) {
  this.stats.spins += 1;
  this.stats.totalStars -= betAmount;
  
  if (winAmount > 0) {
    this.stats.spinsWon += 1;
    this.stats.totalWinnings += winAmount;
    this.stats.totalStars += winAmount;
    
    if (winAmount > this.stats.biggestWin) {
      this.stats.biggestWin = winAmount;
    }
  } else {
    this.stats.spinsLost += 1;
  }
  
  this.lastActive = new Date();
  return this.save();
};

// Метод для обновления статистики игры грейфер
userSchema.methods.updateGrabberStats = function(score, level, starsEarned) {
  this.grabberGamesPlayed += 1;
  this.grabberTotalScore += score;
  this.stars += starsEarned;
  
  if (score > this.grabberHighScore) {
    this.grabberHighScore = score;
  }
  
  if (level > this.grabberMaxLevel) {
    this.grabberMaxLevel = level;
  }
  
  // Добавляем в историю игр
  this.grabberGameHistory.push({
    score,
    level,
    starsEarned,
    timestamp: new Date()
  });
  
  // Ограничиваем историю до последних 50 игр
  if (this.grabberGameHistory.length > 50) {
    this.grabberGameHistory = this.grabberGameHistory.slice(-50);
  }
  
  this.lastActive = new Date();
  return this.save();
};

// Метод для добавления лягушки в инвентарь
userSchema.methods.addFrog = function(frogId) {
  if (!this.inventory.frogs.includes(frogId)) {
    this.inventory.frogs.push(frogId);
    this.stats.frogsOwned += 1;
    return this.save();
  }
  return Promise.resolve(this);
};

// Метод для добавления NFT в инвентарь
userSchema.methods.addNFT = function(nftId) {
  if (!this.inventory.nfts.includes(nftId)) {
    this.inventory.nfts.push(nftId);
    this.stats.nftsMinted += 1;
    return this.save();
  }
  return Promise.resolve(this);
};

// Метод для обработки покупки
userSchema.methods.processPurchase = function(itemId, amount, currency, stars, premium = false, nftCount = 0, spins = 0) {
  this.stats.totalStars += stars;
  this.stats.totalSpent += amount;
  this.stats.purchasesCount += 1;
  
  if (premium) {
    this.isPremium = true;
    this.premiumExpiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 дней
  }
  
  if (nftCount > 0) {
    this.stats.nftsMinted += nftCount;
  }
  
  if (spins > 0) {
    this.stats.spins += spins;
  }
  
  // Добавляем в историю платежей
  this.paymentHistory.push({
    itemId,
    amount,
    currency,
    stars,
    status: 'completed'
  });
  
  this.lastActive = new Date();
  return this.save();
};

// Метод для проверки Premium статуса
userSchema.methods.isPremiumActive = function() {
  return this.isPremium && 
    (!this.premiumExpiresAt || this.premiumExpiresAt > new Date());
};

// Виртуальное поле для дней Premium
userSchema.virtual('premiumDaysLeft').get(function() {
  if (!this.isPremiumActive()) return 0;
  if (!this.premiumExpiresAt) return 999; // Бессрочный Premium
  return Math.ceil((this.premiumExpiresAt - new Date()) / (1000 * 60 * 60 * 24));
});

// Виртуальное поле для статистики слот-машины
userSchema.virtual('spinWinRate').get(function() {
  if (this.stats.spins === 0) return 0;
  return Math.round((this.stats.spinsWon / this.stats.spins) * 100);
});

// Виртуальное поле для среднего выигрыша
userSchema.virtual('averageWin').get(function() {
  if (this.stats.spinsWon === 0) return 0;
  return Math.round(this.stats.totalWinnings / this.stats.spinsWon);
});

// Виртуальное поле для средней оценки в игре грейфер
userSchema.virtual('grabberAverageScore').get(function() {
  if (this.grabberGamesPlayed === 0) return 0;
  return Math.round(this.grabberTotalScore / this.grabberGamesPlayed);
});

module.exports = mongoose.model('User', userSchema); 