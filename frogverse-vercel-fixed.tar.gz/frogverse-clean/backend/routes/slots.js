const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Получение баланса пользователя
router.get('/balance/:telegramId', async (req, res) => {
  try {
    const { telegramId } = req.params;
    
    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.json({
      success: true,
      balance: user.stats.totalStars || 0,
      spins: user.stats.spins || 0,
      canSpin: (user.stats.totalStars || 0) >= 10
    });

  } catch (error) {
    console.error('Error getting balance:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Обработка крутки в слот-машине
router.post('/spin', async (req, res) => {
  try {
    const { telegramId, betAmount, winAmount, newBalance } = req.body;

    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Проверяем, что у пользователя достаточно звезд
    if (user.stats.totalStars < betAmount) {
      return res.status(400).json({
        success: false,
        error: 'Insufficient balance'
      });
    }

    // Обновляем статистику слот-машины
    await user.updateSpinStats(betAmount, winAmount);

    res.json({
      success: true,
      newBalance: user.stats.totalStars,
      winAmount,
      spinStats: {
        totalSpins: user.stats.spins,
        spinsWon: user.stats.spinsWon,
        spinsLost: user.stats.spinsLost,
        winRate: user.spinWinRate,
        totalWinnings: user.stats.totalWinnings,
        biggestWin: user.stats.biggestWin,
        averageWin: user.averageWin
      }
    });

  } catch (error) {
    console.error('Error processing spin:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Получение статистики слот-машины
router.get('/stats/:telegramId', async (req, res) => {
  try {
    const { telegramId } = req.params;
    
    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.json({
      success: true,
      stats: {
        totalSpins: user.stats.spins || 0,
        spinsWon: user.stats.spinsWon || 0,
        spinsLost: user.stats.spinsLost || 0,
        winRate: user.spinWinRate || 0,
        totalWinnings: user.stats.totalWinnings || 0,
        biggestWin: user.stats.biggestWin || 0,
        averageWin: user.averageWin || 0,
        currentBalance: user.stats.totalStars || 0
      }
    });

  } catch (error) {
    console.error('Error getting spin stats:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Ежедневный бонус
router.get('/daily-bonus/:telegramId', async (req, res) => {
  try {
    const { telegramId } = req.params;
    
    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Проверяем, когда пользователь последний раз получал бонус
    const lastBonus = user.referralRewards.lastClaimed;
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    const available = !lastBonus || lastBonus < oneDayAgo;

    res.json({
      success: true,
      available,
      lastClaimed: lastBonus
    });

  } catch (error) {
    console.error('Error checking daily bonus:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Получение ежедневного бонуса
router.post('/daily-bonus', async (req, res) => {
  try {
    const { telegramId } = req.body;

    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Проверяем, когда пользователь последний раз получал бонус
    const lastBonus = user.referralRewards.lastClaimed;
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    if (lastBonus && lastBonus > oneDayAgo) {
      return res.status(400).json({
        success: false,
        error: 'Daily bonus already claimed'
      });
    }

    // Вычисляем бонус (базовый + бонус за Premium)
    let bonusAmount = 50; // Базовый бонус
    if (user.isPremiumActive()) {
      bonusAmount *= 2; // Двойной бонус для Premium
    }

    // Добавляем бонус
    user.stats.totalStars += bonusAmount;
    user.referralRewards.lastClaimed = now;
    user.referralRewards.totalEarned += bonusAmount;

    await user.save();

    res.json({
      success: true,
      bonusAmount,
      newBalance: user.stats.totalStars,
      isPremium: user.isPremiumActive()
    });

  } catch (error) {
    console.error('Error claiming daily bonus:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Получение информации о крутках
router.get('/spins/:telegramId', async (req, res) => {
  try {
    const { telegramId } = req.params;
    
    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.json({
      success: true,
      spins: user.stats.spins || 0,
      totalStars: user.stats.totalStars || 0,
      canSpin: (user.stats.totalStars || 0) >= 10,
      spinCost: 10, // Стоимость одной крутки
      premiumActive: user.isPremiumActive()
    });

  } catch (error) {
    console.error('Error getting spins info:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Покупка круток через звезды (альтернативный способ)
router.post('/buy-spins', async (req, res) => {
  try {
    const { telegramId, spinAmount } = req.body;

    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Стоимость: 10 звезд за крутку
    const cost = spinAmount * 10;

    if (user.stats.totalStars < cost) {
      return res.status(400).json({
        success: false,
        error: 'Insufficient balance'
      });
    }

    // Покупаем крутки
    user.stats.totalStars -= cost;
    user.stats.spins += spinAmount;

    await user.save();

    res.json({
      success: true,
      spinsPurchased: spinAmount,
      cost,
      newBalance: user.stats.totalStars,
      totalSpins: user.stats.spins
    });

  } catch (error) {
    console.error('Error buying spins:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Получение лидерборда слот-машины
router.get('/leaderboard', async (req, res) => {
  try {
    const users = await User.find({})
      .sort({ 'stats.totalWinnings': -1 })
      .limit(10)
      .select('telegramId username firstName stats.totalWinnings stats.biggestWin stats.spins');

    const leaderboard = users.map((user, index) => ({
      rank: index + 1,
      telegramId: user.telegramId,
      username: user.username || user.firstName || 'Anonymous',
      totalWinnings: user.stats.totalWinnings || 0,
      biggestWin: user.stats.biggestWin || 0,
      totalSpins: user.stats.spins || 0
    }));

    res.json({
      success: true,
      leaderboard
    });

  } catch (error) {
    console.error('Error getting leaderboard:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Получение джекпота
router.get('/jackpot', async (req, res) => {
  try {
    // В реальном приложении джекпот мог бы храниться в отдельной коллекции
    // Пока возвращаем фиксированное значение
    const jackpot = 10000;

    res.json({
      success: true,
      jackpot,
      currency: 'stars'
    });

  } catch (error) {
    console.error('Error getting jackpot:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Получение истории круток пользователя
router.get('/history/:telegramId', async (req, res) => {
  try {
    const { telegramId } = req.params;
    const { limit = 20, offset = 0 } = req.query;
    
    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // В реальном приложении здесь была бы отдельная коллекция для истории круток
    // Пока возвращаем заглушку
    const history = [
      {
        id: '1',
        betAmount: 10,
        winAmount: 50,
        symbols: ['💎', '💎', '💎'],
        date: new Date().toISOString(),
        type: 'win'
      },
      {
        id: '2',
        betAmount: 10,
        winAmount: 0,
        symbols: ['🍀', '⭐', '🎰'],
        date: new Date(Date.now() - 60000).toISOString(),
        type: 'loss'
      }
    ];

    res.json({
      success: true,
      history: history.slice(offset, offset + parseInt(limit)),
      total: history.length
    });

  } catch (error) {
    console.error('Error getting spin history:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

module.exports = router; 