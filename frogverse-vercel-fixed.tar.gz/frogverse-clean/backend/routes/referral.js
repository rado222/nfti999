const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Referral = require('../models/Referral');
const NFTGenerator = require('../utils/nftGenerator');

// Генерация реферального кода для пользователя
router.post('/generate-code', async (req, res) => {
  try {
    const { telegramId } = req.body;
    
    if (!telegramId) {
      return res.status(400).json({ error: 'Telegram ID is required' });
    }

    let user = await User.findOne({ telegramId });
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Генерируем код если его нет
    if (!user.referralCode) {
      await user.generateReferralCode();
    }

    res.json({
      success: true,
      referralCode: user.referralCode,
      message: 'Referral code generated successfully'
    });

  } catch (error) {
    console.error('Error generating referral code:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Обработка входа по реферальной ссылке
router.post('/join', async (req, res) => {
  try {
    const { telegramId, referralCode } = req.body;
    
    if (!telegramId || !referralCode) {
      return res.status(400).json({ error: 'Telegram ID and referral code are required' });
    }

    // Проверяем существование реферального кода
    const referral = await Referral.findOne({ code: referralCode });
    if (!referral) {
      return res.status(404).json({ error: 'Invalid referral code' });
    }

    // Проверяем, не является ли пользователь сам себе рефералом
    if (referral.referrerId === telegramId) {
      return res.status(400).json({ error: 'Cannot refer yourself' });
    }

    // Проверяем, не был ли пользователь уже приглашен
    const existingReferred = referral.referred.find(ref => ref.userId === telegramId);
    if (existingReferred) {
      return res.status(400).json({ error: 'User already referred' });
    }

    // Создаем или обновляем пользователя
    let user = await User.findOne({ telegramId });
    if (!user) {
      user = new User({
        telegramId,
        referredBy: referralCode
      });
    } else {
      user.referredBy = referralCode;
    }
    await user.save();

    // Добавляем пользователя в список рефералов
    await referral.addReferred(telegramId);

    res.json({
      success: true,
      message: 'Successfully joined with referral code',
      referrerId: referral.referrerId
    });

  } catch (error) {
    console.error('Error processing referral join:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Активация реферала (после первого боя)
router.post('/activate', async (req, res) => {
  try {
    const { telegramId } = req.body;
    
    if (!telegramId) {
      return res.status(400).json({ error: 'Telegram ID is required' });
    }

    // Находим пользователя
    const user = await User.findOne({ telegramId });
    if (!user || !user.referredBy) {
      return res.status(404).json({ error: 'User not found or not referred' });
    }

    // Находим реферальную запись
    const referral = await Referral.findOne({ code: user.referredBy });
    if (!referral) {
      return res.status(404).json({ error: 'Referral record not found' });
    }

    // Активируем реферала
    await referral.activateReferred(telegramId);

    // Начисляем награду пригласившему
    const referrer = await User.findOne({ telegramId: referral.referrerId });
    if (referrer) {
      referrer.referralRewards.pendingRewards += 1;
      await referrer.save();
    }

    res.json({
      success: true,
      message: 'Referral activated successfully',
      rewardGranted: true
    });

  } catch (error) {
    console.error('Error activating referral:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение статистики рефералов
router.get('/stats/:telegramId', async (req, res) => {
  try {
    const { telegramId } = req.params;
    
    const referral = await Referral.findOne({ referrerId: telegramId });
    const user = await User.findOne({ telegramId });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const stats = {
      totalReferrals: referral ? referral.totalReferrals : 0,
      activeReferrals: referral ? referral.activeReferrals : 0,
      totalRewards: referral ? referral.totalRewards : 0,
      pendingRewards: user.referralRewards.pendingRewards,
      totalEarned: user.referralRewards.totalEarned,
      referralCode: user.referralCode
    };

    res.json({
      success: true,
      stats
    });

  } catch (error) {
    console.error('Error getting referral stats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение списка рефералов
router.get('/list/:telegramId', async (req, res) => {
  try {
    const { telegramId } = req.params;
    
    const referral = await Referral.findOne({ referrerId: telegramId });
    
    if (!referral) {
      return res.json({
        success: true,
        referrals: []
      });
    }

    const referrals = referral.referred.map(ref => ({
      userId: ref.userId,
      joinedAt: ref.joinedAt,
      isActive: ref.isActive,
      battlesPlayed: ref.battlesPlayed,
      rewardClaimed: ref.rewardClaimed
    }));

    res.json({
      success: true,
      referrals
    });

  } catch (error) {
    console.error('Error getting referral list:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение награды за рефералов
router.post('/claim-reward', async (req, res) => {
  try {
    const { telegramId } = req.body;
    
    if (!telegramId) {
      return res.status(400).json({ error: 'Telegram ID is required' });
    }

    const user = await User.findOne({ telegramId });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (user.referralRewards.pendingRewards <= 0) {
      return res.status(400).json({ error: 'No pending rewards to claim' });
    }

    // Генерируем NFT-лягушку как награду
    const nftGenerator = new NFTGenerator();
    const tokenId = Date.now(); // Простой способ генерации уникального ID
    const nft = await nftGenerator.generateNFT(tokenId);

    // Добавляем NFT в инвентарь пользователя
    await user.addNFT(tokenId);

    // Обновляем статистику наград
    user.referralRewards.pendingRewards -= 1;
    user.referralRewards.totalEarned += 1;
    user.referralRewards.lastClaimed = new Date();
    await user.save();

    res.json({
      success: true,
      message: 'Reward claimed successfully',
      nft: {
        tokenId,
        image: nft.metadata.image,
        metadata: nft.metadata
      },
      remainingRewards: user.referralRewards.pendingRewards
    });

  } catch (error) {
    console.error('Error claiming reward:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Генерация реферальной ссылки для Telegram
router.post('/generate-link', async (req, res) => {
  try {
    const { telegramId, botUsername } = req.body;
    
    if (!telegramId || !botUsername) {
      return res.status(400).json({ error: 'Telegram ID and bot username are required' });
    }

    const user = await User.findOne({ telegramId });
    if (!user || !user.referralCode) {
      return res.status(404).json({ error: 'User not found or no referral code' });
    }

    const referralLink = `https://t.me/${botUsername}?start=${user.referralCode}`;
    const shareMessage = `🐸 Join Frogverse and get exclusive rewards! Use my referral code: ${user.referralCode}\n\n${referralLink}`;

    res.json({
      success: true,
      referralLink,
      shareMessage,
      referralCode: user.referralCode
    });

  } catch (error) {
    console.error('Error generating referral link:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router; 