const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Read frogs data
const getFrogs = () => {
  const frogsPath = path.join(__dirname, '../db/frogs.json');
  const frogsData = fs.readFileSync(frogsPath, 'utf8');
  return JSON.parse(frogsData);
};

// Save frogs data
const saveFrogs = (frogs) => {
  const frogsPath = path.join(__dirname, '../db/frogs.json');
  fs.writeFileSync(frogsPath, JSON.stringify(frogs, null, 2));
};

router.post('/', (req, res) => {
  try {
    const { frogId, opponentId } = req.body;
    
    if (!frogId || !opponentId) {
      return res.status(400).json({ error: 'Missing frogId or opponentId' });
    }

    const frogs = getFrogs();
    const frog = frogs.find(f => f.id === frogId);
    const opponent = frogs.find(f => f.id === opponentId);

    if (!frog || !opponent) {
      return res.status(404).json({ error: 'Frog not found' });
    }

    // Calculate battle result
    const frogScore = frog.level + Math.random() * frog.power;
    const opponentScore = opponent.level + Math.random() * opponent.power;
    
    const win = frogScore > opponentScore;
    const stars = win ? Math.floor(Math.random() * 5) + 5 : Math.floor(Math.random() * 2) + 1; // 5-10 stars for win, 1-2 for loss

    // Update frog's stars
    frog.stars += stars;
    saveFrogs(frogs);

    res.json({ 
      result: win ? 'win' : 'lose', 
      stars,
      frogScore: Math.floor(frogScore),
      opponentScore: Math.floor(opponentScore),
      message: win ? 'Victory! Your frog is stronger!' : 'Defeat! Train harder!'
    });

  } catch (error) {
    console.error('Fight error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all frogs
router.get('/frogs', (req, res) => {
  try {
    const frogs = getFrogs();
    res.json(frogs);
  } catch (error) {
    console.error('Get frogs error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get frog by ID
router.get('/frogs/:id', (req, res) => {
  try {
    const frogs = getFrogs();
    const frog = frogs.find(f => f.id === req.params.id);
    
    if (!frog) {
      return res.status(404).json({ error: 'Frog not found' });
    }
    
    res.json(frog);
  } catch (error) {
    console.error('Get frog error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router; 