const fs = require('fs').promises;
const path = require('path');

// Конфигурация слоев NFT
const LAYER_CONFIG = {
  backgrounds: [
    { name: 'forest', rarity: 'common', weight: 30 },
    { name: 'swamp', rarity: 'common', weight: 25 },
    { name: 'crystal_cave', rarity: 'rare', weight: 20 },
    { name: 'volcano', rarity: 'epic', weight: 15 },
    { name: 'cosmic_void', rarity: 'legendary', weight: 10 }
  ],
  skins: [
    { name: 'green', rarity: 'common', weight: 35 },
    { name: 'blue', rarity: 'common', weight: 25 },
    { name: 'purple', rarity: 'rare', weight: 20 },
    { name: 'golden', rarity: 'epic', weight: 15 },
    { name: 'rainbow', rarity: 'legendary', weight: 5 }
  ],
  eyes: [
    { name: 'normal', rarity: 'common', weight: 40 },
    { name: 'angry', rarity: 'common', weight: 25 },
    { name: 'happy', rarity: 'rare', weight: 20 },
    { name: 'laser', rarity: 'epic', weight: 10 },
    { name: 'cosmic', rarity: 'legendary', weight: 5 }
  ],
  artifacts: [
    { name: 'none', rarity: 'common', weight: 50 },
    { name: 'crown', rarity: 'rare', weight: 25 },
    { name: 'sword', rarity: 'epic', weight: 15 },
    { name: 'staff', rarity: 'epic', weight: 10 }
  ],
  auras: [
    { name: 'none', rarity: 'common', weight: 60 },
    { name: 'fire', rarity: 'rare', weight: 20 },
    { name: 'ice', rarity: 'rare', weight: 15 },
    { name: 'lightning', rarity: 'epic', weight: 5 }
  ]
};

class NFTGenerator {
  constructor() {
    this.layersPath = path.join(__dirname, '../assets/layers');
  }

  // Выбор случайного элемента с учетом веса
  selectRandomElement(elements) {
    const totalWeight = elements.reduce((sum, element) => sum + element.weight, 0);
    let random = Math.random() * totalWeight;
    
    for (const element of elements) {
      random -= element.weight;
      if (random <= 0) {
        return element;
      }
    }
    return elements[0];
  }

  // Генерация случайной комбинации слоев
  generateRandomCombination() {
    return {
      background: this.selectRandomElement(LAYER_CONFIG.backgrounds),
      skin: this.selectRandomElement(LAYER_CONFIG.skins),
      eyes: this.selectRandomElement(LAYER_CONFIG.eyes),
      artifact: this.selectRandomElement(LAYER_CONFIG.artifacts),
      aura: this.selectRandomElement(LAYER_CONFIG.auras)
    };
  }

  // Создание простого SVG изображения (замена canvas)
  generateSVGImage(combination) {
    const colors = {
      green: '#4CAF50',
      blue: '#2196F3',
      purple: '#9C27B0',
      golden: '#FFD700',
      rainbow: 'url(#rainbow)',
      forest: '#2E7D32',
      swamp: '#4A148C',
      crystal_cave: '#0277BD',
      volcano: '#D84315',
      cosmic_void: '#1A237E'
    };

    const bgColor = colors[combination.background.name] || '#4CAF50';
    const skinColor = colors[combination.skin.name] || '#4CAF50';

    return `<?xml version="1.0" encoding="UTF-8"?>
<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="rainbow" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#ff0000"/>
      <stop offset="20%" style="stop-color:#ff8000"/>
      <stop offset="40%" style="stop-color:#ffff00"/>
      <stop offset="60%" style="stop-color:#00ff00"/>
      <stop offset="80%" style="stop-color:#0080ff"/>
      <stop offset="100%" style="stop-color:#8000ff"/>
    </linearGradient>
  </defs>
  
  <!-- Background -->
  <rect width="512" height="512" fill="${bgColor}"/>
  
  <!-- Frog body -->
  <ellipse cx="256" cy="300" rx="120" ry="80" fill="${skinColor}"/>
  
  <!-- Frog head -->
  <circle cx="256" cy="200" r="60" fill="${skinColor}"/>
  
  <!-- Eyes -->
  <circle cx="240" cy="190" r="15" fill="white"/>
  <circle cx="272" cy="190" r="15" fill="white"/>
  <circle cx="240" cy="190" r="8" fill="black"/>
  <circle cx="272" cy="190" r="8" fill="black"/>
  
  <!-- Eye expression based on type -->
  ${this.getEyeExpression(combination.eyes.name)}
  
  <!-- Artifacts -->
  ${this.getArtifactSVG(combination.artifact.name)}
  
  <!-- Aura effects -->
  ${this.getAuraSVG(combination.aura.name)}
  
  <!-- Text -->
  <text x="256" y="450" text-anchor="middle" fill="white" font-family="Arial" font-size="24" font-weight="bold">
    Frogverse NFT
  </text>
</svg>`;
  }

  getEyeExpression(eyeType) {
    switch (eyeType) {
      case 'angry':
        return `
          <line x1="230" y1="180" x2="245" y2="185" stroke="black" stroke-width="3"/>
          <line x1="282" y1="180" x2="267" y2="185" stroke="black" stroke-width="3"/>
        `;
      case 'happy':
        return `
          <path d="M 240 200 Q 256 210 272 200" stroke="black" stroke-width="3" fill="none"/>
        `;
      case 'laser':
        return `
          <circle cx="240" cy="190" r="8" fill="red"/>
          <circle cx="272" cy="190" r="8" fill="red"/>
          <line x1="240" y1="190" x2="200" y2="170" stroke="red" stroke-width="2"/>
          <line x1="272" y1="190" x2="312" y2="170" stroke="red" stroke-width="2"/>
        `;
      case 'cosmic':
        return `
          <circle cx="240" cy="190" r="8" fill="url(#rainbow)"/>
          <circle cx="272" cy="190" r="8" fill="url(#rainbow)"/>
        `;
      default:
        return '';
    }
  }

  getArtifactSVG(artifactType) {
    switch (artifactType) {
      case 'crown':
        return `
          <path d="M 200 150 L 220 130 L 240 140 L 256 125 L 272 140 L 292 130 L 312 150 L 200 150" 
                fill="gold" stroke="orange" stroke-width="2"/>
          <circle cx="256" cy="135" r="8" fill="red"/>
        `;
      case 'sword':
        return `
          <rect x="250" y="100" width="12" height="80" fill="silver"/>
          <rect x="245" y="90" width="22" height="20" fill="gold"/>
        `;
      case 'staff':
        return `
          <rect x="252" y="100" width="8" height="80" fill="brown"/>
          <circle cx="256" cy="95" r="15" fill="purple"/>
        `;
      default:
        return '';
    }
  }

  getAuraSVG(auraType) {
    switch (auraType) {
      case 'fire':
        return `
          <circle cx="256" cy="256" r="150" fill="none" stroke="red" stroke-width="3" opacity="0.3">
            <animate attributeName="r" values="150;160;150" dur="2s" repeatCount="indefinite"/>
          </circle>
        `;
      case 'ice':
        return `
          <circle cx="256" cy="256" r="150" fill="none" stroke="cyan" stroke-width="3" opacity="0.3">
            <animate attributeName="r" values="150;155;150" dur="3s" repeatCount="indefinite"/>
          </circle>
        `;
      case 'lightning':
        return `
          <path d="M 200 200 L 220 180 L 240 200 L 260 180 L 280 200" 
                stroke="yellow" stroke-width="4" fill="none" opacity="0.7">
            <animate attributeName="opacity" values="0.7;1;0.7" dur="1s" repeatCount="indefinite"/>
          </path>
        `;
      default:
        return '';
    }
  }

  // Генерация метаданных NFT
  generateMetadata(combination, tokenId) {
    const attributes = [];
    
    // Добавление атрибутов для каждого слоя
    Object.entries(combination).forEach(([layerType, element]) => {
      if (element.name !== 'none') {
        attributes.push({
          trait_type: layerType.charAt(0).toUpperCase() + layerType.slice(1),
          value: element.name.replace('_', ' '),
          rarity: element.rarity
        });
      }
    });

    // Вычисление общей редкости
    const rarities = attributes.map(attr => attr.rarity);
    const overallRarity = this.calculateOverallRarity(rarities);

    return {
      name: `Frogverse Frog #${tokenId}`,
      description: "A unique frog NFT from the Frogverse collection",
      image: `https://your-domain.com/nfts/${tokenId}.svg`,
      external_url: "https://frogverse.com",
      attributes: attributes,
      rarity: overallRarity,
      generation: {
        background: combination.background.name,
        skin: combination.skin.name,
        eyes: combination.eyes.name,
        artifact: combination.artifact.name,
        aura: combination.aura.name
      }
    };
  }

  // Вычисление общей редкости
  calculateOverallRarity(rarities) {
    const rarityScores = {
      'common': 1,
      'rare': 2,
      'epic': 3,
      'legendary': 4
    };

    const totalScore = rarities.reduce((sum, rarity) => sum + rarityScores[rarity], 0);
    const averageScore = totalScore / rarities.length;

    if (averageScore >= 3.5) return 'legendary';
    if (averageScore >= 2.5) return 'epic';
    if (averageScore >= 1.5) return 'rare';
    return 'common';
  }

  // Сохранение NFT
  async saveNFT(tokenId, svgContent, metadata) {
    const nftPath = path.join(__dirname, '../public/nfts');
    const svgPath = path.join(nftPath, `${tokenId}.svg`);
    const metadataPath = path.join(nftPath, `${tokenId}.json`);

    // Создание директории если не существует
    await fs.mkdir(nftPath, { recursive: true });

    // Сохранение SVG изображения
    await fs.writeFile(svgPath, svgContent);

    // Сохранение метаданных
    await fs.writeFile(metadataPath, JSON.stringify(metadata, null, 2));

    return {
      tokenId,
      svgPath,
      metadataPath,
      metadata
    };
  }

  // Генерация полного NFT
  async generateNFT(tokenId) {
    const combination = this.generateRandomCombination();
    const svgContent = this.generateSVGImage(combination);
    const metadata = this.generateMetadata(combination, tokenId);
    
    const result = await this.saveNFT(tokenId, svgContent, metadata);
    
    return {
      ...result,
      combination
    };
  }

  // Генерация множественных NFT
  async generateMultipleNFTs(startId, count) {
    const results = [];
    
    for (let i = 0; i < count; i++) {
      const tokenId = startId + i;
      console.log(`Generating NFT #${tokenId}...`);
      
      try {
        const nft = await this.generateNFT(tokenId);
        results.push(nft);
      } catch (error) {
        console.error(`Error generating NFT #${tokenId}:`, error);
      }
    }
    
    return results;
  }
}

module.exports = NFTGenerator; 