# 💳 Настройка платежей в Frogverse

## 🚀 Быстрый старт

### 1. Создание бота
1. Открой [@BotFather](https://t.me/botfather) в Telegram
2. Отправь `/newbot`
3. Название: `Frogverse Game Bot`
4. Username: `frogverse_game_bot`
5. Сохрани токен

### 2. Настройка платежей
1. Отправь `/mybots` BotFather
2. Выбери созданного бота
3. Нажми "Payments"
4. Выбери "Telegram Stars (XTR)"
5. Сохрани Payment Provider Token

### 3. Настройка переменных
```bash
cd backend
cp env.example .env
```

Отредактируй `.env`:
```env
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_BOT_USERNAME=frogverse_game_bot
PAYMENT_PROVIDER_TOKEN=your_payment_provider_token
MONGODB_URI=mongodb://localhost:27017/frogverse
PORT=3001
NODE_ENV=development
```

### 4. Установка зависимостей
```bash
cd backend
npm install
```

### 5. Тестирование
```bash
npm run test-payment
```

### 6. Запуск
```bash
# В папке frogverse
npm run dev
```

## 🔧 Детальная настройка

### Команды бота
Отправь BotFather:
```
/setcommands
```

Выбери бота и отправь:
```
start - Запустить игру Frogverse
balance - Проверить баланс
buy - Купить звезды
premium - Premium подписка
help - Помощь
```

### Настройка Mini App
1. Отправь `/newapp` BotFather
2. Выбери бота
3. Название: `Frogverse`
4. Описание: `🐸 Epic frog battle game with NFT collection!`
5. URL: `https://your-domain.vercel.app`

## 🧪 Тестирование платежей

### Локальное тестирование
```bash
cd backend
npm run test-payment
```

### Тестовый платеж через API
```bash
curl -X POST http://localhost:3001/api/payments/test-payment \
  -H "Content-Type: application/json" \
  -d '{"userId": "test_user", "amount": 100}'
```

## 🌐 Деплой

### Vercel
1. Подключи репозиторий к Vercel
2. Настрой переменные окружения в Vercel Dashboard
3. Деплой автоматически запустится

### Railway
1. Подключи GitHub репозиторий
2. Настрой переменные окружения
3. Деплой автоматически запустится

## 🔍 Отладка

### Проверка бота
```bash
curl "https://api.telegram.org/bot<TOKEN>/getMe"
```

### Проверка платежей
```bash
curl "https://api.telegram.org/bot<TOKEN>/getUpdates"
```

### Логи сервера
```bash
tail -f backend/server.log
```

## 🛡️ Безопасность

- ✅ Никогда не коммить токены в git
- ✅ Используй HTTPS в продакшене
- ✅ Валидируй все платежи на сервере
- ✅ Логируй все транзакции
- ✅ Используй webhook для продакшена

## 📱 Использование в игре

1. Открой игру в Telegram
2. Перейди в профиль
3. Нажми "Пополнить баланс"
4. Выбери сумму
5. Подтверди платеж
6. Получи звезды!

## 🆘 Поддержка

Если что-то не работает:

1. Проверь токены в `.env`
2. Убедись что бот создан правильно
3. Проверь логи сервера
4. Убедись что MongoDB запущена
5. Проверь консоль браузера на ошибки

## 💡 Полезные ссылки

- [Telegram Bot API](https://core.telegram.org/bots/api)
- [Telegram Payments](https://core.telegram.org/bots/payments)
- [Telegram Stars](https://t.me/telegramstars)
- [BotFather](https://t.me/botfather) 