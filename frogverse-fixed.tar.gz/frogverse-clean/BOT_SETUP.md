# 🤖 Настройка бота @WWNFT_BOT

## ✅ Что уже готово:
- ✅ Бот создан: @WWNFT_BOT
- ✅ Токен настроен: `8176024168:AAEE-l0LdOnfj8OEM--f2-kjWrrpDY5hvuA`
- ✅ Сервер запущен на порту 3001
- ✅ Фронтенд запущен на порту 3002

## 🔧 Настройка платежей

### 1. Открой @BotFather
Перейди в [@BotFather](https://t.me/botfather)

### 2. Настрой платежи
1. Отправь `/mybots`
2. Выбери `@WWNFT_BOT`
3. Нажми "Payments"
4. Выбери провайдера:
   - **Telegram Stars (XTR)** - для Telegram Stars
   - **Stripe** - для карт
   - **CryptoBot** - для криптовалют

### 3. Получи Payment Provider Token
После настройки платежей BotFather даст тебе Payment Provider Token.

### 4. Обнови .env файл
```bash
cd backend
nano .env
```

Замени строку:
```env
PAYMENT_PROVIDER_TOKEN=your_payment_provider_token_here
```

На:
```env
PAYMENT_PROVIDER_TOKEN=твой_реальный_payment_token
```

### 5. Перезапусти сервер
```bash
# Останови текущий процесс (Ctrl+C)
# Затем запусти заново:
npm run dev
```

## 🎮 Настройка Mini App

### 1. Создай Mini App
1. Отправь `/newapp` BotFather
2. Выбери `@WWNFT_BOT`
3. Название: `Frogverse`
4. Описание: `🐸 Epic frog battle game with NFT collection!`
5. URL: `http://localhost:3002` (для разработки)

### 2. Настрой команды бота
Отправь BotFather:
```
/setcommands
```

Выбери `@WWNFT_BOT` и отправь:
```
start - Запустить игру Frogverse
balance - Проверить баланс
buy - Купить звезды
premium - Premium подписка
help - Помощь
```

## 🧪 Тестирование

### 1. Проверь бота
Отправь `/start` боту @WWNFT_BOT

### 2. Открой игру
1. Открой http://localhost:3002
2. Перейди в профиль
3. Попробуй пополнить баланс

### 3. Тест платежей
```bash
cd backend
npm run test-payment
```

## 🚀 Деплой на продакшен

### 1. Vercel
1. Подключи GitHub к Vercel
2. Настрой переменные окружения:
   - `TELEGRAM_BOT_TOKEN`
   - `PAYMENT_PROVIDER_TOKEN`
   - `MONGODB_URI`
3. Деплой автоматически запустится

### 2. Обнови URL в BotFather
После деплоя обнови URL Mini App на продакшен домен.

## 📱 Использование

1. Открой @WWNFT_BOT в Telegram
2. Нажми "Играть в Frogverse"
3. Сражайся лягушками
4. Играй в слот-машину
5. Пополняй баланс через профиль

## 🆘 Отладка

### Проверь логи:
```bash
tail -f backend/server.log
```

### Проверь статус бота:
```bash
curl "https://api.telegram.org/bot8176024168:AAEE-l0LdOnfj8OEM--f2-kjWrrpDY5hvuA/getMe"
```

### Проверь платежи:
```bash
curl "https://api.telegram.org/bot8176024168:AAEE-l0LdOnfj8OEM--f2-kjWrrpDY5hvuA/getUpdates"
```

## 🎯 Следующие шаги:

1. **Настрой платежи** в @BotFather
2. **Получи Payment Provider Token**
3. **Обнови .env файл**
4. **Перезапусти сервер**
5. **Протестируй платежи**

После этого все будет работать! 🚀 