import React, { useState, useEffect } from 'react';
import FrogCard from './components/FrogCard.jsx';
import BattleArena from './components/BattleArena';
import SlotMachine from './components/SlotMachine';
import './App.css';

function App() {
  const [frogs, setFrogs] = useState([]);
  const [selectedFrog, setSelectedFrog] = useState(null);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('battle');
  const [telegramWebApp, setTelegramWebApp] = useState(null);
  const [theme, setTheme] = useState('light');
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    initializeTelegramWebApp();
    fetchUserData();
    fetchFrogs();
  }, []);

  const initializeTelegramWebApp = () => {
    if (window.Telegram && window.Telegram.WebApp) {
      setTelegramWebApp(window.Telegram.WebApp);
    }
  };

  const fetchUserData = async () => {
    // TODO: заменить на реальный API
    setUser({
      id: '123456789',
      firstName: 'FrogUser',
      stats: { totalStars: 777 },
      isPremium: true,
      referralCode: 'FROG777',
    });
    setLoading(false);
  };

  const fetchFrogs = async () => {
    // TODO: заменить на реальный API
    setFrogs([
      { id: 1, name: 'Pepe', level: 5, power: 42, rarity: 'common', stars: 100 },
      { id: 2, name: 'Froggo', level: 3, power: 30, rarity: 'rare', stars: 150 },
      { id: 3, name: 'Kermit', level: 7, power: 55, rarity: 'epic', stars: 200 },
    ]);
  };

  const handleFrogSelect = (frog) => {
    setSelectedFrog(frog);
  };

  const onUserUpdate = (updatedUser) => {
    setUser(updatedUser);
  };

  const handleTopUp = (amount) => {
    if (!telegramWebApp) {
      alert('Эта функция доступна только в Telegram');
      return;
    }

    let title, description, prices;
    
    if (amount === 'premium') {
      title = 'Premium подписка на 1 месяц';
      description = 'Получите Premium статус на 30 дней';
      prices = [{ label: 'Premium 1 месяц', amount: 20 }];
    } else {
      title = `Пополнение баланса на ${amount} звезд`;
      description = `Пополнение игрового баланса`;
      prices = [{ label: `${amount} звезд`, amount: amount / 100 }];
    }

    // Создаем инвойс
    const payload = `topup_${amount}_${user?.id || '123456789'}_${Date.now()}`;
    
    // Показываем инвойс пользователю
    telegramWebApp.showInvoice(
      `https://t.me/your_bot?start=${payload}`,
      (status) => {
        if (status === 'paid') {
          // Обрабатываем успешную оплату
          const newStars = amount === 'premium' ? 0 : amount;
          const newUser = {
            ...user,
            stats: { 
              ...user.stats, 
              totalStars: (user.stats?.totalStars || 0) + newStars 
            },
            isPremium: amount === 'premium' ? true : user.isPremium
          };
          setUser(newUser);
          
          telegramWebApp.showAlert(
            amount === 'premium' 
              ? '👑 Premium активирован на 30 дней!' 
              : `✅ Баланс пополнен на ${amount} звезд!`
          );
        } else if (status === 'cancelled') {
          telegramWebApp.showAlert('Пополнение отменено');
        } else if (status === 'failed') {
          telegramWebApp.showAlert('Ошибка оплаты. Попробуйте еще раз.');
        }
      }
    );
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'battle':
        return (
          <div className="battle-tab-content">
            <section className="frogs-section">
              <h2>Твои лягушки</h2>
              <div className="frogs-grid">
                {frogs.map((frog) => (
                  <FrogCard
                    key={frog.id}
                    frog={frog}
                    isSelected={selectedFrog?.id === frog.id}
                    onSelect={() => handleFrogSelect(frog)}
                  />
                ))}
              </div>
            </section>
            {selectedFrog && (
              <section className="battle-section">
                <h2>Арена</h2>
                <BattleArena
                  selectedFrog={selectedFrog}
                  opponents={frogs.filter(f => f.id !== selectedFrog.id)}
                  onBattleComplete={() => fetchFrogs()}
                  onUserUpdate={onUserUpdate}
                  showNotification={() => {}}
                />
              </section>
            )}
          </div>
        );
      case 'slots':
        return (
          <section className="slots-section">
            <SlotMachine user={user} onUserUpdate={onUserUpdate} showNotification={() => {}} />
          </section>
        );
      case 'profile':
        return (
          <section className="profile-section">
            <h2>Профиль</h2>
            <div className="profile-card">
              <div className="profile-avatar">🐸</div>
              <div className="profile-info">
                <div className="profile-name">{user?.firstName}</div>
                <div className="profile-stars">⭐ {user?.stats?.totalStars || 0}</div>
                {user?.isPremium && <div className="profile-premium">👑 Premium</div>}
                <div className="profile-ref">Реф. код: <b>{user?.referralCode}</b></div>
              </div>
            </div>
            
            {/* Кнопки пополнения баланса */}
            <div className="balance-topup-section">
              <h3>💳 Пополнить баланс</h3>
              <div className="topup-buttons">
                <button 
                  className="topup-btn"
                  onClick={() => handleTopUp(100)}
                >
                  💫 100 звезд - 1 XTR
                </button>
                <button 
                  className="topup-btn"
                  onClick={() => handleTopUp(500)}
                >
                  💫 500 звезд - 5 XTR
                </button>
                <button 
                  className="topup-btn"
                  onClick={() => handleTopUp(1000)}
                >
                  💫 1000 звезд - 10 XTR
                </button>
                <button 
                  className="topup-btn premium"
                  onClick={() => handleTopUp('premium')}
                >
                  👑 Premium на 1 месяц - 20 XTR
                </button>
              </div>
            </div>
          </section>
        );
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="app">
        <div className="loading-screen">
          <div className="loading-spinner"></div>
          <h2>🐸 Загрузка Frogverse...</h2>
          <p>Подготовка к приключениям</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`app theme-${theme}`}>
      <header className="app-header">
        <div className="header-content">
          <h1>🐸 Frogverse</h1>
        </div>
      </header>

      <nav className="main-nav-3d">
        <button
          className={`main-nav-btn${activeTab === 'battle' ? ' active' : ''}`}
          onClick={() => setActiveTab('battle')}
        >
          ⚔️ Битвы
        </button>
        <button
          className={`main-nav-btn${activeTab === 'slots' ? ' active' : ''}`}
          onClick={() => setActiveTab('slots')}
        >
          🎰 Слоты
        </button>
        <button
          className={`main-nav-btn${activeTab === 'profile' ? ' active' : ''}`}
          onClick={() => setActiveTab('profile')}
        >
          👤 Профиль
        </button>
      </nav>

      <main className="main-content">
        {renderTabContent()}
      </main>
    </div>
  );
}

export default App; 