const handleTopUp = async (amount) => {
  if (!telegramWebApp) {
    alert('Telegram WebApp не доступен');
    return;
  }

  try {
    // Создаем уникальный payload для платежа
    const payload = btoa(JSON.stringify({
      userId: telegramWebApp.initDataUnsafe?.user?.id || 'unknown',
      amount: amount,
      timestamp: Date.now(),
      type: 'topup'
    }));

    // Показываем инвойс через Telegram Bot
    telegramWebApp.showInvoice(
      `https://t.me/WWNFT_BOT?start=${payload}`,
      (status) => {
        console.log('Payment status:', status);
        
        if (status === 'paid') {
          // Платеж успешен - обновляем баланс
          setBalance(prev => prev + amount);
          setShowPaymentSuccess(true);
          
          // Сохраняем в localStorage
          const newBalance = balance + amount;
          localStorage.setItem('frogverse_balance', newBalance.toString());
          
          // Показываем уведомление
          telegramWebApp.showAlert(`✅ Баланс пополнен на ${amount} звезд!`);
          
          setTimeout(() => setShowPaymentSuccess(false), 3000);
        } else if (status === 'cancelled') {
          telegramWebApp.showAlert('❌ Платеж отменен');
        } else if (status === 'failed') {
          telegramWebApp.showAlert('❌ Ошибка платежа. Попробуйте еще раз.');
        }
      }
    );
  } catch (error) {
    console.error('Payment error:', error);
    telegramWebApp.showAlert('❌ Ошибка при создании платежа');
  }
}; 