import React, { useState, useEffect } from 'react';
import './ReferralSystem.css';

const ReferralSystem = ({ user }) => {
  const [referralCode, setReferralCode] = useState('');
  const [referralStats, setReferralStats] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [telegramWebApp, setTelegramWebApp] = useState(null);

  useEffect(() => {
    if (window.Telegram && window.Telegram.WebApp) {
      setTelegramWebApp(window.Telegram.WebApp);
    }
    
    if (user && user.id) {
      generateReferralCode();
      fetchReferralStats();
    }
  }, [user]);

  const generateReferralCode = async () => {
    if (!user || !user.id) return;

    try {
      const response = await fetch('/api/referral/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ telegramId: user.id }),
      });

      const data = await response.json();
      if (data.success) {
        setReferralCode(data.referralCode);
      }
    } catch (error) {
      console.error('Error generating referral code:', error);
    }
  };

  const fetchReferralStats = async () => {
    if (!user || !user.id) return;

    try {
      const response = await fetch(`/api/referral/stats/${user.id}`);
      const data = await response.json();
      if (data.success) {
        setReferralStats(data.stats);
      }
    } catch (error) {
      console.error('Error fetching referral stats:', error);
    }
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setMessage('✅ Код скопирован!');
      
      // Показываем уведомление в Telegram
      if (telegramWebApp) {
        telegramWebApp.showAlert('✅ Реферальный код скопирован в буфер обмена!');
      }
      
      setTimeout(() => setMessage(''), 3000);
    } catch (error) {
      console.error('Error copying to clipboard:', error);
      setMessage('❌ Ошибка копирования');
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const shareReferralLink = () => {
    if (!referralCode) return;

    const referralLink = `${window.location.origin}?ref=${referralCode}`;
    
    if (telegramWebApp) {
      // Используем Telegram WebApp для шаринга
      telegramWebApp.shareUrl(
        referralLink,
        `🐸 Присоединяйся к Frogverse! Используй мой реферальный код: ${referralCode}`
      );
    } else {
      // Fallback для обычного браузера
      copyToClipboard(referralLink);
    }
  };

  const claimReward = async () => {
    if (!user || !user.id) return;

    setLoading(true);
    try {
      const response = await fetch('/api/referral/claim-reward', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ telegramId: user.id }),
      });

      const data = await response.json();
      if (data.success) {
        setMessage(`🎉 Награда получена! +${data.rewardAmount} звезд`);
        
        // Показываем уведомление в Telegram
        if (telegramWebApp) {
          telegramWebApp.showAlert(`🎉 Награда получена! +${data.rewardAmount} звезд`);
        }
        
        // Обновляем статистику
        fetchReferralStats();
      } else {
        setMessage(data.error || 'Ошибка получения награды');
      }
    } catch (error) {
      console.error('Error claiming reward:', error);
      setMessage('Ошибка получения награды');
    } finally {
      setLoading(false);
      setTimeout(() => setMessage(''), 5000);
    }
  };

  if (!user) {
    return (
      <div className="referral-system">
        <div className="referral-card">
          <h2>🌟 Реферальная система</h2>
          <p>Войдите в игру, чтобы получить доступ к реферальной системе</p>
        </div>
      </div>
    );
  }

  return (
    <div className="referral-system">
      <div className="referral-header">
        <h2>🌟 Реферальная система</h2>
        <p>Приглашайте друзей и получайте награды!</p>
      </div>

      {/* Реферальный код */}
      <div className="referral-card">
        <h3>🎯 Ваш реферальный код</h3>
        <div className="referral-code-container">
          <div className="referral-code">
            <span className="code-text">{referralCode || 'Загрузка...'}</span>
            <button 
              className="copy-btn"
              onClick={() => copyToClipboard(referralCode)}
              disabled={!referralCode}
            >
              📋
            </button>
          </div>
        </div>
        
        <div className="referral-actions">
          <button 
            className="share-btn"
            onClick={shareReferralLink}
            disabled={!referralCode}
          >
            📤 Поделиться ссылкой
          </button>
        </div>
      </div>

      {/* Статистика */}
      {referralStats && (
        <div className="referral-card">
          <h3>📊 Статистика рефералов</h3>
          <div className="stats-grid">
            <div className="stat-item">
              <span className="stat-number">{referralStats.totalReferrals || 0}</span>
              <span className="stat-label">Всего приглашено</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">{referralStats.activeReferrals || 0}</span>
              <span className="stat-label">Активных</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">{referralStats.totalRewards || 0}</span>
              <span className="stat-label">Получено наград</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">{referralStats.pendingRewards || 0}</span>
              <span className="stat-label">Ожидает наград</span>
            </div>
          </div>
        </div>
      )}

      {/* Список рефералов */}
      {referralStats && referralStats.referrals && referralStats.referrals.length > 0 && (
        <div className="referral-card">
          <h3>👥 Ваши рефералы</h3>
          <div className="referrals-list">
            {referralStats.referrals.map((referral, index) => (
              <div key={index} className="referral-item">
                <div className="referral-info">
                  <span className="referral-name">
                    {referral.username || `User ${referral.telegramId}`}
                  </span>
                  <span className={`referral-status ${referral.isActive ? 'active' : 'pending'}`}>
                    {referral.isActive ? '✅ Активен' : '⏳ Ожидает активации'}
                  </span>
                </div>
                <span className="referral-date">
                  {new Date(referral.joinedAt).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Получение награды */}
      {referralStats && referralStats.pendingRewards > 0 && (
        <div className="referral-card">
          <h3>🎁 Доступные награды</h3>
          <p>У вас есть {referralStats.pendingRewards} неполученных наград</p>
          <button 
            className="claim-btn"
            onClick={claimReward}
            disabled={loading}
          >
            {loading ? '⏳ Получение...' : '🎁 Получить награду'}
          </button>
        </div>
      )}

      {/* Информация о наградах */}
      <div className="referral-card">
        <h3>💎 Система наград</h3>
        <div className="rewards-info">
          <div className="reward-item">
            <span className="reward-icon">🐸</span>
            <div className="reward-text">
              <strong>За каждого активного реферала:</strong>
              <p>Уникальная NFT-лягушка + 50 звезд</p>
            </div>
          </div>
          <div className="reward-item">
            <span className="reward-icon">⭐</span>
            <div className="reward-text">
              <strong>Бонус за 5 рефералов:</strong>
              <p>Редкая лягушка + 100 звезд</p>
            </div>
          </div>
          <div className="reward-item">
            <span className="reward-icon">👑</span>
            <div className="reward-text">
              <strong>Бонус за 10 рефералов:</strong>
              <p>Легендарная лягушка + 200 звезд</p>
            </div>
          </div>
        </div>
      </div>

      {/* Сообщения */}
      {message && (
        <div className={`message ${message.includes('✅') ? 'success' : 'error'}`}>
          {message}
        </div>
      )}
    </div>
  );
};

export default ReferralSystem; 