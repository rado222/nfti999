import React, { useState, useEffect } from 'react';
import './SlotMachine.css';

const SlotMachine = ({ user, onUserUpdate, showNotification }) => {
  const [balance, setBalance] = useState(100);
  const [betAmount, setBetAmount] = useState(10);
  const [isSpinning, setIsSpinning] = useState(false);
  const [reels, setReels] = useState([
    ['🍀', '⭐', '🎰', '💎', '🐸'],
    ['🍀', '⭐', '🎰', '💎', '🐸'],
    ['🍀', '⭐', '🎰', '💎', '🐸'],
    ['🍀', '⭐', '🎰', '💎', '🐸'],
    ['🍀', '⭐', '🎰', '💎', '🐸']
  ]);
  const [winAmount, setWinAmount] = useState(0);
  const [showWin, setShowWin] = useState(false);
  const [jackpot, setJackpot] = useState(10000);
  const [dailyBonus, setDailyBonus] = useState(true);

  // Символы и их множители
  const symbols = {
    '💎': { name: 'Diamond', multiplier: 150, color: '#00ffff' },
    '🐸': { name: 'Frog', multiplier: 100, color: '#32cd32' },
    '💚': { name: 'Heart', multiplier: 75, color: '#ff69b4' },
    '🚀': { name: 'Rocket', multiplier: 100, color: '#ff4500' },
    '⭐': { name: 'Star', multiplier: 200, color: '#ffd700' },
    '🌀': { name: 'Vortex', multiplier: 50, color: '#9370db' },
    '🎁': { name: 'Gift', multiplier: 25, color: '#ff6347' },
    '🌹': { name: 'Rose', multiplier: 25, color: '#dc143c' },
    '🍰': { name: 'Cake', multiplier: 50, color: '#ffb6c1' },
    '💍': { name: 'Ring', multiplier: 100, color: '#ffd700' },
    '🥂': { name: 'Champagne', multiplier: 200, color: '#f0e68c' },
    '🥚': { name: 'Easter Egg', multiplier: 250, color: '#ff69b4' }
  };

  useEffect(() => {
    // Загрузка баланса пользователя
    if (user) {
      setBalance(user.stats?.totalStars || 100);
    }
  }, [user]);

  const claimDailyBonus = () => {
    const bonusAmount = 50;
    setBalance(prev => prev + bonusAmount);
    setDailyBonus(false);
    if (showNotification) {
      showNotification(`🎁 Ежедневный бонус получен: +${bonusAmount} звезд!`, 'success');
    }
    
    // Обновляем данные пользователя
    if (onUserUpdate) {
      onUserUpdate({
        ...user,
        stats: { ...user.stats, totalStars: balance + bonusAmount }
      });
    }
  };

  const spin = async () => {
    if (isSpinning || balance < betAmount) {
      if (balance < betAmount && showNotification) {
        showNotification('Недостаточно звезд для крутки!', 'error');
      }
      return;
    }

    setIsSpinning(true);
    setWinAmount(0);
    setShowWin(false);

    // Анимация вращения
    const spinDuration = 3000;
    const spinInterval = 100;
    const totalSteps = spinDuration / spinInterval;

    for (let step = 0; step < totalSteps; step++) {
      await new Promise(resolve => setTimeout(resolve, spinInterval));
      
      setReels(prevReels => prevReels.map(reel => {
        const newReel = [...reel];
        const symbolKeys = Object.keys(symbols);
        for (let i = 0; i < newReel.length; i++) {
          newReel[i] = symbolKeys[Math.floor(Math.random() * symbolKeys.length)];
        }
        return newReel;
      }));
    }

    // Генерируем результат
    const result = generateResult();
    setReels(result.reels);

    // Вычисляем выигрыш
    const win = calculateWin(result.reels, betAmount);
    setWinAmount(win);

    // Обновляем баланс
    const newBalance = balance - betAmount + win;
    setBalance(newBalance);

    // Обновляем джекпот
    if (win > 0) {
      setJackpot(prev => Math.max(10000, prev - win * 0.1));
    }

    // Показываем результат
    if (win > 0) {
      setShowWin(true);
      setTimeout(() => setShowWin(false), 3000);
    }

    // Обновляем данные пользователя
    if (onUserUpdate) {
      onUserUpdate({
        ...user,
        stats: { ...user.stats, totalStars: newBalance }
      });
    }

    setIsSpinning(false);
  };

  const generateResult = () => {
    const symbolKeys = Object.keys(symbols);
    const reels = Array(5).fill(null).map(() => 
      Array(3).fill(null).map(() => 
        symbolKeys[Math.floor(Math.random() * symbolKeys.length)]
      )
    );
    return { reels };
  };

  const calculateWin = (reels, bet) => {
    // Проверяем линии выигрыша
    const lines = [
      [reels[0][1], reels[1][1], reels[2][1], reels[3][1], reels[4][1]], // Центральная линия
      [reels[0][0], reels[1][0], reels[2][0], reels[3][0], reels[4][0]], // Верхняя линия
      [reels[0][2], reels[1][2], reels[2][2], reels[3][2], reels[4][2]]  // Нижняя линия
    ];

    let totalWin = 0;

    lines.forEach(line => {
      const firstSymbol = line[0];
      let consecutiveCount = 1;

      for (let i = 1; i < line.length; i++) {
        if (line[i] === firstSymbol) {
          consecutiveCount++;
        } else {
          break;
        }
      }

      if (consecutiveCount >= 3) {
        const multiplier = symbols[firstSymbol]?.multiplier || 1;
        totalWin += bet * multiplier * (consecutiveCount / 5);
      }
    });

    // Джекпот за 5 одинаковых символов
    if (lines.some(line => line.every(symbol => symbol === line[0]))) {
      totalWin += jackpot;
    }

    return Math.floor(totalWin);
  };

  const getBetOptions = () => [5, 10, 25, 50, 100];

  return (
    <div className="slot-machine">
      {/* Космические частицы */}
      <div className="cosmic-particles">
        {Array.from({ length: 20 }).map((_, i) => (
          <div key={i} className="particle" style={{
            left: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 3}s`,
            animationDuration: `${3 + Math.random() * 2}s`
          }}></div>
        ))}
      </div>

      {/* Анимированная лягушка-маскот */}
      <div className="frog-mascot">
        <div className="frog-body">🐸</div>
        <div className="frog-eyes">
          <div className="eye left"></div>
          <div className="eye right"></div>
        </div>
        <div className="frog-mouth"></div>
      </div>

      {/* Заголовок */}
      <div className="slot-header">
        <h2>🎰 Lucky 777</h2>
        <div className="jackpot-display">
          <span className="jackpot-label">JACKPOT</span>
          <span className="jackpot-amount">⭐ {jackpot.toLocaleString()}</span>
        </div>
      </div>

      {/* Информация о балансе */}
      <div className="balance-info">
        <div className="balance-display">
          <span className="balance-label">Баланс:</span>
          <span className="balance-amount">⭐ {balance.toLocaleString()}</span>
        </div>
        
        {/* Ежедневный бонус */}
        {dailyBonus && (
          <button className="daily-bonus-btn" onClick={claimDailyBonus}>
            🎁 Получить ежедневный бонус
          </button>
        )}
      </div>

      {/* Слот-машина */}
      <div className="slot-container">
        <div className="reels-container">
          {reels.map((reel, reelIndex) => (
            <div key={reelIndex} className="reel">
              {reel.map((symbol, symbolIndex) => (
                <div 
                  key={symbolIndex} 
                  className={`symbol ${isSpinning ? 'spinning' : ''}`}
                  style={{ 
                    color: symbols[symbol]?.color || '#fff',
                    textShadow: `0 0 10px ${symbols[symbol]?.color || '#fff'}`
                  }}
                >
                  {symbol}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Управление ставками */}
      <div className="betting-controls">
        <div className="bet-amount">
          <span>Ставка: ⭐ {betAmount}</span>
          <div className="bet-buttons">
            {getBetOptions().map(amount => (
              <button
                key={amount}
                className={`bet-btn ${betAmount === amount ? 'active' : ''}`}
                onClick={() => setBetAmount(amount)}
                disabled={isSpinning}
              >
                {amount}
              </button>
            ))}
          </div>
        </div>

        <button 
          className={`spin-btn ${isSpinning ? 'spinning' : ''} ${balance < betAmount ? 'disabled' : ''}`}
          onClick={spin}
          disabled={isSpinning || balance < betAmount}
        >
          {isSpinning ? '🎰 Крутим...' : '🎰 Крутить'}
        </button>
      </div>

      {/* Таблица выигрышей */}
      <div className="paytable">
        <h3>🎯 Таблица выигрышей</h3>
        <div className="paytable-grid">
          {Object.entries(symbols).map(([symbol, info]) => (
            <div key={symbol} className="paytable-item">
              <span className="symbol">{symbol}</span>
              <span className="multiplier">{info.multiplier}x</span>
            </div>
          ))}
        </div>
      </div>

      {/* Уведомление о выигрыше */}
      {showWin && (
        <div className="win-notification">
          <div className="win-content">
            <h2>🎉 ПОБЕДА!</h2>
            <p>Выигрыш: ⭐ {winAmount.toLocaleString()}</p>
            <div className="celebration-particles">
              {Array.from({ length: 10 }).map((_, i) => (
                <div key={i} className="celebration-particle">✨</div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SlotMachine; 