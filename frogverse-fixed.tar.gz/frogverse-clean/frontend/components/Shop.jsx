import React, { useState, useEffect } from 'react';
import './Shop.css';

const Shop = ({ user, onPurchase }) => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [telegramWebApp, setTelegramWebApp] = useState(null);

  // Товары в магазине
  const shopItems = [
    {
      id: 'stars_100',
      title: '100 Звезд',
      description: '100 звезд для игры в Frogverse',
      price: 1, // 1 XTR
      stars: 100,
      icon: '⭐',
      color: '#FFD700'
    },
    {
      id: 'stars_500',
      title: '500 Звезд',
      description: '500 звезд для игры в Frogverse',
      price: 5, // 5 XTR
      stars: 500,
      icon: '⭐⭐',
      color: '#FFA500',
      popular: true
    },
    {
      id: 'stars_1000',
      title: '1000 Звезд',
      description: '1000 звезд для игры в Frogverse',
      price: 10, // 10 XTR
      stars: 1000,
      icon: '⭐⭐⭐',
      color: '#FF6347'
    },
    {
      id: 'premium_month',
      title: 'Premium на 1 месяц',
      description: 'Премиум подписка с бонусами',
      price: 20, // 20 XTR
      stars: 500,
      premium: true,
      premiumDays: 30,
      icon: '👑',
      color: '#9370DB'
    },
    {
      id: 'nft_pack',
      title: 'NFT Pack (5 лягушек)',
      description: 'Набор из 5 уникальных NFT лягушек',
      price: 15, // 15 XTR
      stars: 300,
      nftCount: 5,
      icon: '🐸',
      color: '#32CD32'
    }
  ];

  useEffect(() => {
    setItems(shopItems);
    setLoading(false);

    // Инициализация Telegram WebApp
    if (window.Telegram && window.Telegram.WebApp) {
      setTelegramWebApp(window.Telegram.WebApp);
    }
  }, []);

  const handlePurchase = async (item) => {
    if (!telegramWebApp) {
      alert('Эта функция доступна только в Telegram');
      return;
    }

    try {
      // Показываем индикатор загрузки
      telegramWebApp.MainButton.showProgress();
      
      // Создаем инвойс через Telegram WebApp
      const invoiceParams = {
        title: item.title,
        description: item.description,
        payload: `${item.id}_${user.id}_${Date.now()}`,
        currency: 'XTR',
        prices: [{ label: item.title, amount: item.price * 100 }], // XTR в минимальных единицах
        provider_token: '',
        need_name: false,
        need_phone_number: false,
        need_email: false,
        need_shipping_address: false,
        is_flexible: false
      };

      // Отправляем инвойс через Telegram Bot API
      const response = await fetch('/api/payments/create-invoice', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chatId: user.id,
          ...invoiceParams
        }),
      });

      if (response.ok) {
        const data = await response.json();
        
        // Показываем инвойс пользователю
        telegramWebApp.showInvoice(data.invoice_url, (status) => {
          if (status === 'paid') {
            // Обработка успешной оплаты
            handleSuccessfulPayment(item);
          } else if (status === 'cancelled') {
            telegramWebApp.showAlert('Покупка отменена');
          } else if (status === 'failed') {
            telegramWebApp.showAlert('Ошибка оплаты. Попробуйте еще раз.');
          }
        });
      } else {
        throw new Error('Failed to create invoice');
      }
    } catch (error) {
      console.error('Error creating invoice:', error);
      telegramWebApp.showAlert('Ошибка создания счета. Попробуйте позже.');
    } finally {
      telegramWebApp.MainButton.hideProgress();
    }
  };

  const handleSuccessfulPayment = async (item) => {
    try {
      // Обновляем баланс пользователя
      const response = await fetch('/api/payments/process-payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          telegramId: user.id,
          itemId: item.id,
          stars: item.stars,
          premium: item.premium,
          nftCount: item.nftCount
        }),
      });

      if (response.ok) {
        const data = await response.json();
        
        // Показываем сообщение об успешной покупке
        let message = `✅ Покупка успешна!\n\n`;
        message += `💰 Получено: ${item.stars} звезд\n`;
        message += `💳 Стоимость: ${item.price} XTR\n`;
        message += `💎 Новый баланс: ${data.newBalance} звезд\n\n`;
        
        if (item.premium) {
          message += `👑 Premium активирован на ${item.premiumDays} дней!\n`;
        }
        
        if (item.nftCount) {
          message += `🐸 Получено ${item.nftCount} NFT лягушек!\n`;
        }
        
        message += `\n🎮 Играйте и получайте удовольствие!`;
        
        telegramWebApp.showAlert(message);
        
        // Обновляем данные пользователя
        if (onPurchase) {
          onPurchase(data);
        }
      } else {
        throw new Error('Failed to process payment');
      }
    } catch (error) {
      console.error('Error processing payment:', error);
      telegramWebApp.showAlert('Ошибка обработки платежа. Обратитесь в поддержку.');
    }
  };

  const openTelegramBot = () => {
    if (telegramWebApp) {
      telegramWebApp.openTelegramLink(`https://t.me/${process.env.REACT_APP_BOT_USERNAME || 'your_bot'}`);
    }
  };

  if (loading) {
    return (
      <div className="shop-container">
        <div className="loading">
          <div className="spinner"></div>
          <p>Загрузка магазина...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="shop-container">
      <div className="shop-header">
        <h2>🛍️ Магазин Frogverse</h2>
        <p>Пополняйте баланс и получайте бонусы!</p>
        {user && (
          <div className="user-balance">
            <span>💰 Ваш баланс: {user.stats?.totalStars || 0} звезд</span>
          </div>
        )}
      </div>

      <div className="shop-items">
        {items.map((item) => (
          <div key={item.id} className={`shop-item ${item.popular ? 'popular' : ''}`}>
            {item.popular && <div className="popular-badge">🔥 Популярно</div>}
            
            <div className="item-icon" style={{ backgroundColor: item.color }}>
              {item.icon}
            </div>
            
            <div className="item-content">
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              
              <div className="item-details">
                <span className="stars">⭐ {item.stars} звезд</span>
                {item.premium && <span className="premium">👑 Premium</span>}
                {item.nftCount && <span className="nft">🐸 {item.nftCount} NFT</span>}
              </div>
              
              <div className="item-price">
                <span className="price">{item.price} XTR</span>
                <span className="currency">Telegram Stars</span>
              </div>
            </div>
            
            <button 
              className="buy-btn"
              onClick={() => handlePurchase(item)}
              disabled={!telegramWebApp}
            >
              {telegramWebApp ? '💳 Купить' : '📱 Открыть в Telegram'}
            </button>
          </div>
        ))}
      </div>

      {!telegramWebApp && (
        <div className="telegram-notice">
          <p>💡 Для покупок откройте игру в Telegram</p>
          <button className="telegram-btn" onClick={openTelegramBot}>
            📱 Открыть в Telegram
          </button>
        </div>
      )}

      <div className="shop-info">
        <h3>ℹ️ Информация о покупках</h3>
        <ul>
          <li>💳 Оплата производится через Telegram Stars (XTR)</li>
          <li>⚡ Покупки обрабатываются мгновенно</li>
          <li>🔄 Возврат средств в течение 24 часов</li>
          <li>🎮 Звезды можно использовать в игре</li>
          <li>👑 Premium дает дополнительные возможности</li>
        </ul>
      </div>
    </div>
  );
};

export default Shop; 