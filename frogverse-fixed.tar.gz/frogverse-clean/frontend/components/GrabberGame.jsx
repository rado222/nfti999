import React, { useState, useEffect, useRef } from 'react';
import './GrabberGame.css';

const GrabberGame = ({ user, onUserUpdate, showNotification }) => {
  const [score, setScore] = useState(0);
  const [gameActive, setGameActive] = useState(false);
  const [grabberPosition, setGrabberPosition] = useState(50);
  const [isGrabbing, setIsGrabbing] = useState(false);
  const [prizes, setPrizes] = useState([]);
  const [gameSpeed, setGameSpeed] = useState(1);
  const [level, setLevel] = useState(1);
  const [lives, setLives] = useState(3);
  const [highScore, setHighScore] = useState(0);
  
  const gameRef = useRef(null);
  const animationRef = useRef(null);
  const lastTimeRef = useRef(0);

  // Инициализация игры
  useEffect(() => {
    if (gameActive) {
      startGame();
    } else {
      stopGame();
    }
  }, [gameActive]);

  // Обработка клавиш
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (!gameActive) return;
      
      switch (e.key) {
        case 'ArrowLeft':
          e.preventDefault();
          moveGrabber(-5);
          break;
        case 'ArrowRight':
          e.preventDefault();
          moveGrabber(5);
          break;
        case ' ':
          e.preventDefault();
          grab();
          break;
      }
    };

    const handleTouchStart = (e) => {
      if (!gameActive) return;
      e.preventDefault();
      grab();
    };

    const handleTouchMove = (e) => {
      if (!gameActive) return;
      e.preventDefault();
      const touch = e.touches[0];
      const rect = gameRef.current.getBoundingClientRect();
      const x = ((touch.clientX - rect.left) / rect.width) * 100;
      setGrabberPosition(Math.max(10, Math.min(90, x)));
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('touchstart', handleTouchStart, { passive: false });
    window.addEventListener('touchmove', handleTouchMove, { passive: false });

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
    };
  }, [gameActive]);

  const startGame = () => {
    setScore(0);
    setLives(3);
    setLevel(1);
    setGameSpeed(1);
    setPrizes([]);
    setGrabberPosition(50);
    setIsGrabbing(false);
    lastTimeRef.current = performance.now();
    gameLoop();
  };

  const stopGame = () => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  };

  const gameLoop = (currentTime = performance.now()) => {
    if (!gameActive) return;

    const deltaTime = currentTime - lastTimeRef.current;
    lastTimeRef.current = currentTime;

    // Обновление призов
    setPrizes(prevPrizes => {
      const newPrizes = prevPrizes.map(prize => ({
        ...prize,
        y: prize.y + (2 * gameSpeed * deltaTime / 16)
      })).filter(prize => prize.y < 100);

      // Добавление новых призов
      if (Math.random() < 0.02 * gameSpeed) {
        newPrizes.push({
          id: Date.now() + Math.random(),
          x: Math.random() * 80 + 10,
          y: -10,
          type: Math.random() < 0.3 ? 'star' : 'gem',
          value: Math.random() < 0.2 ? 50 : 10
        });
      }

      return newPrizes;
    });

    // Проверка столкновений
    if (isGrabbing) {
      checkCollisions();
    }

    // Увеличение уровня
    if (score > level * 100) {
      setLevel(prev => prev + 1);
      setGameSpeed(prev => prev + 0.2);
      showNotification(`Уровень ${level + 1}! Скорость увеличена!`, 'success');
    }

    animationRef.current = requestAnimationFrame(gameLoop);
  };

  const moveGrabber = (direction) => {
    setGrabberPosition(prev => Math.max(10, Math.min(90, prev + direction)));
  };

  const grab = () => {
    if (isGrabbing) return;
    setIsGrabbing(true);
    setTimeout(() => setIsGrabbing(false), 1000);
  };

  const checkCollisions = () => {
    setPrizes(prevPrizes => {
      const newPrizes = [...prevPrizes];
      const grabbedPrizes = [];

      newPrizes.forEach((prize, index) => {
        if (Math.abs(prize.x - grabberPosition) < 8 && prize.y > 70 && prize.y < 90) {
          grabbedPrizes.push(prize);
          newPrizes.splice(index, 1);
        }
      });

      if (grabbedPrizes.length > 0) {
        const totalValue = grabbedPrizes.reduce((sum, prize) => sum + prize.value, 0);
        setScore(prev => prev + totalValue);
        showNotification(`+${totalValue} очков!`, 'success');
        
        // Обновление баланса пользователя
        if (user && window.Telegram?.WebApp) {
          const newStars = (user.stars || user.stats?.totalStars || 0) + Math.floor(totalValue / 10);
          onUserUpdate({ 
            ...user, 
            stars: newStars,
            stats: { ...user.stats, totalStars: newStars }
          });
        }
      }

      return newPrizes;
    });
  };

  const handleGameOver = () => {
    setGameActive(false);
    if (score > highScore) {
      setHighScore(score);
      showNotification(`Новый рекорд: ${score}!`, 'success');
    }
    
    // Сохранение результатов на сервер
    saveGameResults();
  };

  const saveGameResults = async () => {
    try {
      const response = await fetch('/api/grabber/results', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          score,
          level,
          userId: user?.id
        })
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.starsEarned > 0) {
          const newStars = (user.stars || user.stats?.totalStars || 0) + result.starsEarned;
          onUserUpdate({ 
            ...user, 
            stars: newStars,
            stats: { ...user.stats, totalStars: newStars }
          });
          showNotification(`Получено ${result.starsEarned} ⭐ за игру!`, 'success');
        }
      }
    } catch (error) {
      console.error('Error saving game results:', error);
    }
  };

  const shareScore = () => {
    if (window.Telegram?.WebApp) {
      window.Telegram.WebApp.sendData(JSON.stringify({
        type: 'grabber_score',
        score,
        level
      }));
    }
  };

  const claimDailyBonus = async () => {
    try {
      const response = await fetch('/api/user/daily-bonus', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      });
      
      if (response.ok) {
        const result = await response.json();
        const newStars = (user.stars || user.stats?.totalStars || 0) + result.stars;
        onUserUpdate({ 
          ...user, 
          stars: newStars,
          stats: { ...user.stats, totalStars: newStars }
        });
        showNotification(`Ежедневный бонус: +${result.stars} ⭐`, 'success');
      }
    } catch (error) {
      console.error('Error claiming daily bonus:', error);
      showNotification('Ошибка получения бонуса', 'error');
    }
  };

  return (
    <div className="grabber-game">
      {/* Космические частицы */}
      <div className="cosmic-particles">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="particle"
            style={{
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${5 + Math.random() * 5}s`
            }}
          />
        ))}
      </div>

      {/* Заголовок */}
      <div className="game-header">
        <h2>🎯 Frogverse Grabber</h2>
        <p className="game-subtitle">Лови призы грейфером!</p>
      </div>

      {/* Информация о балансе */}
      <div className="balance-info">
        <div className="balance-display">
          <span className="balance-label">Баланс:</span>
          <span className="balance-amount">⭐ {user?.stars || user?.stats?.totalStars || 0}</span>
        </div>
        <button className="daily-bonus-btn" onClick={claimDailyBonus}>
          🎁 Ежедневный бонус
        </button>
      </div>

      {/* Игровая статистика */}
      <div className="game-stats">
        <div className="stat-item">
          <span className="stat-label">Счёт</span>
          <span className="stat-value">{score}</span>
        </div>
        <div className="stat-item">
          <span className="stat-label">Уровень</span>
          <span className="stat-value">{level}</span>
        </div>
        <div className="stat-item">
          <span className="stat-label">Жизни</span>
          <span className="stat-value">❤️ {lives}</span>
        </div>
        <div className="stat-item">
          <span className="stat-label">Рекорд</span>
          <span className="stat-value">{highScore}</span>
        </div>
      </div>

      {/* Игровое поле */}
      <div className="game-container" ref={gameRef}>
        <div className="game-area">
          {/* Призы */}
          {prizes.map(prize => (
            <div
              key={prize.id}
              className={`prize ${prize.type}`}
              style={{
                left: `${prize.x}%`,
                top: `${prize.y}%`
              }}
            >
              {prize.type === 'star' ? '⭐' : '💎'}
            </div>
          ))}

          {/* Грейфер */}
          <div 
            className={`grabber ${isGrabbing ? 'grabbing' : ''}`}
            style={{ left: `${grabberPosition}%` }}
          >
            <div className="grabber-arm"></div>
            <div className="grabber-claw"></div>
          </div>

          {/* Дно */}
          <div className="game-bottom"></div>
        </div>
      </div>

      {/* Управление */}
      <div className="game-controls">
        {!gameActive ? (
          <button className="start-btn" onClick={() => setGameActive(true)}>
            🚀 Начать игру
          </button>
        ) : (
          <div className="control-buttons">
            <button 
              className="control-btn left"
              onTouchStart={() => moveGrabber(-5)}
              onMouseDown={() => moveGrabber(-5)}
            >
              ⬅️
            </button>
            <button 
              className="control-btn grab"
              onTouchStart={grab}
              onMouseDown={grab}
            >
              🎯 Захват
            </button>
            <button 
              className="control-btn right"
              onTouchStart={() => moveGrabber(5)}
              onMouseDown={() => moveGrabber(5)}
            >
              ➡️
            </button>
          </div>
        )}
      </div>

      {/* Инструкции */}
      <div className="game-instructions">
        <h3>🎮 Как играть:</h3>
        <ul>
          <li>⬅️➡️ Двигай грейфер влево/вправо</li>
          <li>🎯 Нажимай "Захват" для ловли призов</li>
          <li>⭐ Лови звёзды и драгоценности</li>
          <li>🚀 Набирай очки и повышай уровень</li>
        </ul>
      </div>

      {/* Кнопка поделиться */}
      {score > 0 && !gameActive && (
        <button className="share-btn" onClick={shareScore}>
          📤 Поделиться результатом
        </button>
      )}
    </div>
  );
};

export default GrabberGame; 