import React from 'react';
import './FrogCard.css';

const FrogCard = ({ frog, isSelected, onSelect }) => {
  const getRarityColor = (rarity) => {
    switch (rarity) {
      case 'common': return '#9ca3af';
      case 'rare': return '#3b82f6';
      case 'epic': return '#8b5cf6';
      case 'legendary': return '#f59e0b';
      default: return '#9ca3af';
    }
  };

  const getRarityEmoji = (rarity) => {
    switch (rarity) {
      case 'common': return '🐸';
      case 'rare': return '🐸✨';
      case 'epic': return '🐸💫';
      case 'legendary': return '🐸👑';
      default: return '🐸';
    }
  };

  return (
    <div 
      className={`frog-card ${isSelected ? 'selected' : ''}`}
      onClick={onSelect}
      style={{ borderColor: getRarityColor(frog.rarity) }}
    >
      <div className="frog-header">
        <span className="frog-emoji">{getRarityEmoji(frog.rarity)}</span>
        <span className="frog-rarity" style={{ color: getRarityColor(frog.rarity) }}>
          {frog.rarity.toUpperCase()}
        </span>
      </div>
      
      <div className="frog-name">{frog.name}</div>
      
      <div className="frog-stats">
        <div className="stat">
          <span className="stat-label">Level:</span>
          <span className="stat-value">{frog.level}</span>
        </div>
        <div className="stat">
          <span className="stat-label">Power:</span>
          <span className="stat-value">{frog.power}</span>
        </div>
        <div className="stat">
          <span className="stat-label">Stars:</span>
          <span className="stat-value stars">⭐ {frog.stars}</span>
        </div>
      </div>
      
      {isSelected && (
        <div className="selection-indicator">
          ✓ Selected
        </div>
      )}
    </div>
  );
};

export default FrogCard; 