const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Сохранение результатов игры
router.post('/results', async (req, res) => {
  try {
    const { score, level, userId } = req.body;
    
    if (!userId) {
      return res.status(400).json({ error: 'User ID required' });
    }

    const user = await User.findOne({ telegramId: userId });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Расчет награды
    const starsEarned = Math.floor(score / 100) + Math.floor(level * 5);
    const bonusMultiplier = level > 5 ? 1.5 : 1;
    const finalStars = Math.floor(starsEarned * bonusMultiplier);

    // Обновление статистики пользователя
    const updateData = {
      stars: user.stars + finalStars,
      grabberGamesPlayed: (user.grabberGamesPlayed || 0) + 1,
      grabberTotalScore: (user.grabberTotalScore || 0) + score,
      grabberHighScore: Math.max(user.grabberHighScore || 0, score),
      grabberMaxLevel: Math.max(user.grabberMaxLevel || 0, level)
    };

    // Обновление истории игр
    if (!user.grabberGameHistory) {
      user.grabberGameHistory = [];
    }
    
    user.grabberGameHistory.push({
      score,
      level,
      starsEarned: finalStars,
      timestamp: new Date()
    });

    // Ограничение истории до последних 50 игр
    if (user.grabberGameHistory.length > 50) {
      user.grabberGameHistory = user.grabberGameHistory.slice(-50);
    }

    // Применение обновлений
    Object.assign(user, updateData);
    await user.save();

    res.json({
      success: true,
      starsEarned: finalStars,
      newBalance: user.stars,
      stats: {
        gamesPlayed: user.grabberGamesPlayed,
        totalScore: user.grabberTotalScore,
        highScore: user.grabberHighScore,
        maxLevel: user.grabberMaxLevel
      }
    });

  } catch (error) {
    console.error('Error saving grabber results:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение статистики пользователя
router.get('/stats/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    
    const user = await User.findOne({ telegramId: userId });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      gamesPlayed: user.grabberGamesPlayed || 0,
      totalScore: user.grabberTotalScore || 0,
      highScore: user.grabberHighScore || 0,
      maxLevel: user.grabberMaxLevel || 0,
      averageScore: user.grabberGamesPlayed > 0 
        ? Math.round(user.grabberTotalScore / user.grabberGamesPlayed) 
        : 0,
      gameHistory: user.grabberGameHistory || []
    });

  } catch (error) {
    console.error('Error getting grabber stats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение таблицы лидеров
router.get('/leaderboard', async (req, res) => {
  try {
    const { type = 'highScore', limit = 10 } = req.query;
    
    let sortField;
    switch (type) {
      case 'highScore':
        sortField = 'grabberHighScore';
        break;
      case 'totalScore':
        sortField = 'grabberTotalScore';
        break;
      case 'maxLevel':
        sortField = 'grabberMaxLevel';
        break;
      case 'gamesPlayed':
        sortField = 'grabberGamesPlayed';
        break;
      default:
        sortField = 'grabberHighScore';
    }

    const leaderboard = await User.find({
      [sortField]: { $exists: true, $gt: 0 }
    })
    .sort({ [sortField]: -1 })
    .limit(parseInt(limit))
    .select('username firstName lastName grabberHighScore grabberTotalScore grabberMaxLevel grabberGamesPlayed')
    .lean();

    res.json({
      type,
      leaderboard: leaderboard.map((user, index) => ({
        rank: index + 1,
        username: user.username || `${user.firstName || ''} ${user.lastName || ''}`.trim(),
        score: user[sortField],
        stats: {
          highScore: user.grabberHighScore || 0,
          totalScore: user.grabberTotalScore || 0,
          maxLevel: user.grabberMaxLevel || 0,
          gamesPlayed: user.grabberGamesPlayed || 0
        }
      }))
    });

  } catch (error) {
    console.error('Error getting grabber leaderboard:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение достижений пользователя
router.get('/achievements/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    
    const user = await User.findOne({ telegramId: userId });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const achievements = [];
    const stats = {
      highScore: user.grabberHighScore || 0,
      totalScore: user.grabberTotalScore || 0,
      maxLevel: user.grabberMaxLevel || 0,
      gamesPlayed: user.grabberGamesPlayed || 0
    };

    // Проверка достижений
    if (stats.highScore >= 1000) achievements.push({ id: 'score_1000', name: 'Мастер грейфера', description: 'Набрал 1000+ очков за игру', icon: '🏆' });
    if (stats.highScore >= 500) achievements.push({ id: 'score_500', name: 'Опытный игрок', description: 'Набрал 500+ очков за игру', icon: '🥇' });
    if (stats.highScore >= 100) achievements.push({ id: 'score_100', name: 'Новичок', description: 'Набрал 100+ очков за игру', icon: '🥉' });
    
    if (stats.maxLevel >= 10) achievements.push({ id: 'level_10', name: 'Легенда', description: 'Достиг 10+ уровня', icon: '👑' });
    if (stats.maxLevel >= 5) achievements.push({ id: 'level_5', name: 'Профессионал', description: 'Достиг 5+ уровня', icon: '⭐' });
    if (stats.maxLevel >= 3) achievements.push({ id: 'level_3', name: 'Ученик', description: 'Достиг 3+ уровня', icon: '🌟' });
    
    if (stats.gamesPlayed >= 100) achievements.push({ id: 'games_100', name: 'Ветеран', description: 'Сыграл 100+ игр', icon: '🎮' });
    if (stats.gamesPlayed >= 50) achievements.push({ id: 'games_50', name: 'Регулярный игрок', description: 'Сыграл 50+ игр', icon: '🎯' });
    if (stats.gamesPlayed >= 10) achievements.push({ id: 'games_10', name: 'Активный игрок', description: 'Сыграл 10+ игр', icon: '🎲' });

    if (stats.totalScore >= 10000) achievements.push({ id: 'total_10000', name: 'Миллионер очков', description: 'Набрал 10000+ очков всего', icon: '💰' });
    if (stats.totalScore >= 5000) achievements.push({ id: 'total_5000', name: 'Богач очков', description: 'Набрал 5000+ очков всего', icon: '💎' });
    if (stats.totalScore >= 1000) achievements.push({ id: 'total_1000', name: 'Собиратель очков', description: 'Набрал 1000+ очков всего', icon: '💫' });

    res.json({
      achievements,
      stats,
      totalAchievements: achievements.length
    });

  } catch (error) {
    console.error('Error getting grabber achievements:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение ежедневных заданий
router.get('/daily-challenges/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    
    const user = await User.findOne({ telegramId: userId });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Генерация заданий на основе текущей даты
    const today = new Date().toDateString();
    const seed = today.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
    
    const challenges = [
      {
        id: 'daily_score',
        name: 'Набери очки',
        description: 'Набери 200+ очков за игру',
        target: 200,
        current: user.grabberHighScore || 0,
        reward: 50,
        type: 'score',
        completed: (user.grabberHighScore || 0) >= 200
      },
      {
        id: 'daily_level',
        name: 'Повысь уровень',
        description: 'Достигни 3+ уровня',
        target: 3,
        current: user.grabberMaxLevel || 0,
        reward: 30,
        type: 'level',
        completed: (user.grabberMaxLevel || 0) >= 3
      },
      {
        id: 'daily_games',
        name: 'Сыграй игры',
        description: 'Сыграй 5+ игр сегодня',
        target: 5,
        current: 0, // Будет обновляться в реальном времени
        reward: 20,
        type: 'games',
        completed: false
      }
    ];

    res.json({
      date: today,
      challenges,
      totalReward: challenges.reduce((sum, c) => sum + (c.completed ? c.reward : 0), 0)
    });

  } catch (error) {
    console.error('Error getting daily challenges:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение информации о турнирах
router.get('/tournaments', async (req, res) => {
  try {
    // Здесь можно добавить логику турниров
    const tournaments = [
      {
        id: 'weekly_1',
        name: 'Еженедельный турнир',
        description: 'Соревнуйся с другими игроками',
        startDate: new Date(),
        endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        prize: 1000,
        participants: 0,
        status: 'active'
      }
    ];

    res.json({ tournaments });

  } catch (error) {
    console.error('Error getting tournaments:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router; 