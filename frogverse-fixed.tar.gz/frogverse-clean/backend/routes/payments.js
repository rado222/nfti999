const express = require('express');
const router = express.Router();
const User = require('../models/User');
const TelegramBot = require('node-telegram-bot-api');

// Инициализация бота
const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: false });

// Создание инвойса для оплаты
router.post('/create-invoice', async (req, res) => {
  try {
    const { chatId, title, description, payload, currency, prices, provider_token } = req.body;

    // Проверяем, что все необходимые поля присутствуют
    if (!chatId || !title || !description || !payload || !currency || !prices) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing required fields' 
      });
    }

    // Создаем инвойс через Telegram Bot API
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      return res.status(500).json({ 
        success: false, 
        error: 'Bot token not configured' 
      });
    }

    const invoiceData = {
      chat_id: chatId,
      title,
      description,
      payload,
      currency,
      prices,
      provider_token: provider_token || '',
      need_name: false,
      need_phone_number: false,
      need_email: false,
      need_shipping_address: false,
      is_flexible: false
    };

    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendInvoice`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(invoiceData),
    });

    const result = await response.json();

    if (result.ok) {
      // Возвращаем URL для оплаты
      res.json({
        success: true,
        invoice_url: `https://t.me/${process.env.TELEGRAM_BOT_USERNAME || 'your_bot'}?start=pay_${payload}`,
        invoice_id: result.result.invoice_id
      });
    } else {
      console.error('Telegram API error:', result);
      res.status(500).json({
        success: false,
        error: 'Failed to create invoice',
        details: result.description
      });
    }

  } catch (error) {
    console.error('Error creating invoice:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Обработка успешного платежа
router.post('/process-payment', async (req, res) => {
  try {
    const { telegramId, itemId, stars, premium, nftCount, spins } = req.body;

    // Находим пользователя
    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Обновляем баланс пользователя
    user.stats.totalStars += stars;

    // Активируем Premium если куплен
    if (premium) {
      user.isPremium = true;
      user.premiumExpiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 дней
    }

    // Добавляем NFT если куплены
    if (nftCount) {
      user.stats.nftCount = (user.stats.nftCount || 0) + nftCount;
    }

    // Добавляем крутки если куплены
    if (spins) {
      user.stats.spins = (user.stats.spins || 0) + spins;
    }

    // Сохраняем изменения
    await user.save();

    // Логируем покупку
    console.log(`Payment processed: User ${telegramId} bought ${itemId} for ${stars} stars`);

    res.json({
      success: true,
      newBalance: user.stats.totalStars,
      message: 'Payment processed successfully'
    });

  } catch (error) {
    console.error('Error processing payment:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Создание инвойса для покупки круток
router.post('/create-spin-invoice', async (req, res) => {
  try {
    const { chatId, spinAmount } = req.body;

    if (!chatId || !spinAmount) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing required fields' 
      });
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      return res.status(500).json({ 
        success: false, 
        error: 'Bot token not configured' 
      });
    }

    // Цена: 5 XTR за крутку
    const pricePerSpin = 5;
    const totalPrice = spinAmount * pricePerSpin;

    const invoiceData = {
      chat_id: chatId,
      title: `${spinAmount} круток в слот-машине`,
      description: `Пакет из ${spinAmount} круток для игры в слот-машину Frogverse. Каждая крутка дает 10 звезд в игре!`,
      payload: `spins_${spinAmount}_${chatId}_${Date.now()}`,
      currency: 'XTR',
      prices: [{ label: `${spinAmount} круток`, amount: totalPrice * 100 }], // XTR в минимальных единицах
      provider_token: '',
      need_name: false,
      need_phone_number: false,
      need_email: false,
      need_shipping_address: false,
      is_flexible: false
    };

    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendInvoice`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(invoiceData),
    });

    const result = await response.json();

    if (result.ok) {
      res.json({
        success: true,
        invoice_url: `https://t.me/${process.env.TELEGRAM_BOT_USERNAME || 'your_bot'}?start=pay_spins_${spinAmount}`,
        invoice_id: result.result.invoice_id,
        price: totalPrice,
        stars: spinAmount * 10 // 10 звезд за крутку
      });
    } else {
      console.error('Telegram API error:', result);
      res.status(500).json({
        success: false,
        error: 'Failed to create spin invoice',
        details: result.description
      });
    }

  } catch (error) {
    console.error('Error creating spin invoice:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Обработка покупки круток
router.post('/process-spin-purchase', async (req, res) => {
  try {
    const { telegramId, spinAmount } = req.body;

    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Добавляем звезды за крутки (10 звезд за крутку)
    const starsToAdd = spinAmount * 10;
    user.stats.totalStars += starsToAdd;

    // Добавляем крутки в статистику
    user.stats.spins = (user.stats.spins || 0) + spinAmount;

    await user.save();

    console.log(`Spin purchase processed: User ${telegramId} bought ${spinAmount} spins for ${starsToAdd} stars`);

    res.json({
      success: true,
      newBalance: user.stats.totalStars,
      spinsAdded: spinAmount,
      starsAdded: starsToAdd,
      message: `Successfully purchased ${spinAmount} spins!`
    });

  } catch (error) {
    console.error('Error processing spin purchase:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Получение истории платежей пользователя
router.get('/history/:telegramId', async (req, res) => {
  try {
    const { telegramId } = req.params;
    
    // В реальном приложении здесь была бы отдельная модель для платежей
    // Пока возвращаем заглушку
    res.json({
      success: true,
      payments: [
        {
          id: '1',
          item: '100 Звезд',
          amount: 100,
          currency: 'XTR',
          date: new Date().toISOString(),
          status: 'completed'
        }
      ]
    });

  } catch (error) {
    console.error('Error getting payment history:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Проверка статуса Premium
router.get('/premium-status/:telegramId', async (req, res) => {
  try {
    const { telegramId } = req.params;
    
    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    const isPremium = user.isPremium && 
      (!user.premiumExpiresAt || user.premiumExpiresAt > new Date());

    res.json({
      success: true,
      isPremium,
      premiumExpiresAt: user.premiumExpiresAt,
      daysLeft: isPremium && user.premiumExpiresAt ? 
        Math.ceil((user.premiumExpiresAt - new Date()) / (1000 * 60 * 60 * 24)) : 0
    });

  } catch (error) {
    console.error('Error checking premium status:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Получение информации о крутках пользователя
router.get('/spins/:telegramId', async (req, res) => {
  try {
    const { telegramId } = req.params;
    
    const user = await User.findOne({ telegramId: telegramId.toString() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.json({
      success: true,
      spins: user.stats.spins || 0,
      totalStars: user.stats.totalStars || 0,
      canSpin: (user.stats.totalStars || 0) >= 10 // Минимум 10 звезд для крутки
    });

  } catch (error) {
    console.error('Error getting spins info:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Возврат средств (refund)
router.post('/refund', async (req, res) => {
  try {
    const { telegramId, paymentId, reason } = req.body;

    // В реальном приложении здесь была бы логика возврата через Telegram Bot API
    // Пока возвращаем заглушку
    console.log(`Refund requested: User ${telegramId}, Payment ${paymentId}, Reason: ${reason}`);

    res.json({
      success: true,
      message: 'Refund request submitted',
      refundId: `refund_${Date.now()}`
    });

  } catch (error) {
    console.error('Error processing refund:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Получение доступных товаров
router.get('/items', async (req, res) => {
  try {
    const items = [
      {
        id: 'stars_100',
        title: '100 Звезд',
        description: '100 звезд для игры в Frogverse',
        price: 1,
        stars: 100,
        icon: '⭐',
        color: '#FFD700'
      },
      {
        id: 'stars_500',
        title: '500 Звезд',
        description: '500 звезд для игры в Frogverse',
        price: 5,
        stars: 500,
        icon: '⭐⭐',
        color: '#FFA500',
        popular: true
      },
      {
        id: 'stars_1000',
        title: '1000 Звезд',
        description: '1000 звезд для игры в Frogverse',
        price: 10,
        stars: 1000,
        icon: '⭐⭐⭐',
        color: '#FF6347'
      },
      {
        id: 'premium_month',
        title: 'Premium на 1 месяц',
        description: 'Премиум подписка с бонусами',
        price: 20,
        stars: 500,
        premium: true,
        premiumDays: 30,
        icon: '👑',
        color: '#9370DB'
      },
      {
        id: 'nft_pack',
        title: 'NFT Pack (5 лягушек)',
        description: 'Набор из 5 уникальных NFT лягушек',
        price: 15,
        stars: 300,
        nftCount: 5,
        icon: '🐸',
        color: '#32CD32'
      },
      {
        id: 'spins_10',
        title: '10 круток',
        description: '10 круток в слот-машине',
        price: 50,
        stars: 100,
        spins: 10,
        icon: '🎰',
        color: '#FF69B4'
      },
      {
        id: 'spins_25',
        title: '25 круток',
        description: '25 круток в слот-машине',
        price: 125,
        stars: 250,
        spins: 25,
        icon: '🎰🎰',
        color: '#9370DB'
      },
      {
        id: 'spins_50',
        title: '50 круток',
        description: '50 круток в слот-машине',
        price: 250,
        stars: 500,
        spins: 50,
        icon: '🎰🎰🎰',
        color: '#FF4500'
      }
    ];

    res.json({
      success: true,
      items
    });

  } catch (error) {
    console.error('Error getting items:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// Обработка команды /start с payload для платежей
bot.onText(/\/start (.+)/, async (msg, match) => {
  try {
    const payload = match[1];
    const decodedPayload = JSON.parse(Buffer.from(payload, 'base64').toString());
    
    console.log('Payment payload:', decodedPayload);
    
    // Проверяем тип операции
    if (decodedPayload.type === 'topup') {
      // Создаем инвойс для пополнения баланса
      const invoice = {
        title: `Пополнение баланса на ${decodedPayload.amount} звезд`,
        description: 'Frogverse - пополнение игрового баланса',
        payload: payload,
        provider_token: process.env.PAYMENT_PROVIDER_TOKEN,
        currency: 'XTR', // Telegram Stars
        prices: [{
          label: `${decodedPayload.amount} звезд`,
          amount: decodedPayload.amount * 100 // в копейках
        }],
        start_parameter: payload,
        photo_url: 'https://via.placeholder.com/300x200/4CAF50/FFFFFF?text=Frogverse',
        photo_size: 300,
        photo_width: 300,
        photo_height: 200
      };
      
      // Отправляем инвойс
      await bot.sendInvoice(msg.chat.id, invoice);
      
      // Отправляем сообщение с инструкциями
      await bot.sendMessage(msg.chat.id, 
        `💳 Для пополнения баланса на ${decodedPayload.amount} звезд нажмите кнопку выше.\n\n` +
        `💰 Стоимость: ${decodedPayload.amount} Telegram Stars\n` +
        `🎮 После оплаты баланс автоматически пополнится в игре!`
      );
    }
  } catch (error) {
    console.error('Payment processing error:', error);
    await bot.sendMessage(msg.chat.id, '❌ Ошибка при обработке платежа. Попробуйте еще раз.');
  }
});

// Обработка успешных платежей
bot.on('pre_checkout_query', async (query) => {
  try {
    console.log('Pre-checkout query:', query);
    await bot.answerPreCheckoutQuery(query.id, true);
  } catch (error) {
    console.error('Pre-checkout error:', error);
    await bot.answerPreCheckoutQuery(query.id, false, 'Ошибка при проверке платежа');
  }
});

bot.on('successful_payment', async (msg) => {
  try {
    console.log('Successful payment:', msg.successful_payment);
    
    const payload = msg.successful_payment.invoice_payload;
    const decodedPayload = JSON.parse(Buffer.from(payload, 'base64').toString());
    
    // Обновляем баланс пользователя в базе данных
    const User = require('../models/User');
    const user = await User.findOneAndUpdate(
      { telegramId: decodedPayload.userId },
      { $inc: { balance: decodedPayload.amount } },
      { new: true, upsert: true }
    );
    
    // Отправляем подтверждение
    await bot.sendMessage(msg.chat.id, 
      `✅ Платеж успешно обработан!\n\n` +
      `💰 Пополнено: ${decodedPayload.amount} звезд\n` +
      `💎 Новый баланс: ${user.balance} звезд\n\n` +
      `🎮 Возвращайтесь в игру!`
    );
    
    console.log(`Balance updated for user ${decodedPayload.userId}: +${decodedPayload.amount}`);
    
  } catch (error) {
    console.error('Payment success processing error:', error);
    await bot.sendMessage(msg.chat.id, '❌ Ошибка при обработке платежа. Обратитесь в поддержку.');
  }
});

// API endpoint для проверки статуса платежа
router.get('/status/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const User = require('../models/User');
    
    const user = await User.findOne({ telegramId: userId });
    if (!user) {
      return res.json({ balance: 0 });
    }
    
    res.json({ balance: user.balance });
  } catch (error) {
    console.error('Balance check error:', error);
    res.status(500).json({ error: 'Ошибка при проверке баланса' });
  }
});

// API endpoint для создания тестового платежа (для разработки)
router.post('/test-payment', async (req, res) => {
  try {
    const { userId, amount } = req.body;
    
    // Симулируем успешный платеж
    const User = require('../models/User');
    const user = await User.findOneAndUpdate(
      { telegramId: userId },
      { $inc: { balance: amount } },
      { new: true, upsert: true }
    );
    
    res.json({ 
      success: true, 
      newBalance: user.balance,
      message: `Баланс пополнен на ${amount} звезд (тестовый режим)`
    });
  } catch (error) {
    console.error('Test payment error:', error);
    res.status(500).json({ error: 'Ошибка при тестовом платеже' });
  }
});

module.exports = router; 