const mongoose = require('mongoose');
const User = require('../models/User');
const Referral = require('../models/Referral');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/frogverse';

async function setupDatabase() {
  try {
    console.log('🔌 Connecting to MongoDB...');
    await mongoose.connect(MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('✅ Connected to MongoDB');

    // Очищаем существующие данные
    console.log('🧹 Cleaning existing data...');
    await User.deleteMany({});
    await Referral.deleteMany({});
    console.log('✅ Database cleaned');

    // Создаем тестовых пользователей
    console.log('👥 Creating test users...');
    const testUsers = [
      {
        telegramId: '123456789',
        username: 'testuser1',
        firstName: 'Test',
        lastName: 'User1'
      },
      {
        telegramId: '987654321',
        username: 'testuser2',
        firstName: 'Test',
        lastName: 'User2'
      }
    ];

    for (const userData of testUsers) {
      const user = new User(userData);
      await user.generateReferralCode();
      await user.save();
      console.log(`✅ Created user: ${user.username} with code: ${user.referralCode}`);
    }

    // Создаем реферальные записи
    console.log('🔗 Creating referral records...');
    const users = await User.find();
    
    for (const user of users) {
      const referral = new Referral({
        code: user.referralCode,
        referrerId: user.telegramId
      });
      await referral.save();
      console.log(`✅ Created referral record for: ${user.username}`);
    }

    console.log('🎉 Database setup completed successfully!');
    console.log('\n📊 Summary:');
    console.log(`- Users created: ${users.length}`);
    console.log(`- Referral codes generated: ${users.length}`);
    
    console.log('\n🔑 Test Referral Codes:');
    users.forEach(user => {
      console.log(`- ${user.username}: ${user.referralCode}`);
    });

  } catch (error) {
    console.error('❌ Database setup failed:', error);
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Disconnected from MongoDB');
  }
}

// Запускаем скрипт если он вызван напрямую
if (require.main === module) {
  setupDatabase();
}

module.exports = setupDatabase; 