const NFTGenerator = require('../utils/nftGenerator');
const fs = require('fs').promises;
const path = require('path');

async function generateSampleNFTs() {
  try {
    console.log('🎨 Starting NFT generation...');
    
    const nftGenerator = new NFTGenerator();
    
    // Создаем директорию для слоев если её нет
    const layersPath = path.join(__dirname, '../assets/layers');
    await fs.mkdir(layersPath, { recursive: true });
    
    // Создаем поддиректории для каждого типа слоев
    const layerTypes = ['backgrounds', 'skins', 'eyes', 'artifacts', 'auras'];
    for (const layerType of layerTypes) {
      await fs.mkdir(path.join(layersPath, layerType), { recursive: true });
    }
    
    console.log('📁 Created layer directories');
    console.log('⚠️  Note: You need to add PNG files to the layer directories manually');
    console.log('   - backgrounds/: forest.png, swamp.png, crystal_cave.png, volcano.png, cosmic_void.png');
    console.log('   - skins/: green.png, blue.png, purple.png, golden.png, rainbow.png');
    console.log('   - eyes/: normal.png, angry.png, happy.png, laser.png, cosmic.png');
    console.log('   - artifacts/: none.png, crown.png, sword.png, staff.png');
    console.log('   - auras/: none.png, fire.png, ice.png, lightning.png');
    
    // Генерируем несколько тестовых NFT
    console.log('\n🎯 Generating sample NFTs...');
    const sampleCount = 5;
    const startId = Date.now();
    
    const results = await nftGenerator.generateMultipleNFTs(startId, sampleCount);
    
    console.log(`✅ Generated ${results.length} sample NFTs`);
    
    results.forEach((nft, index) => {
      console.log(`\n🐸 NFT #${nft.tokenId}:`);
      console.log(`   - Rarity: ${nft.metadata.rarity}`);
      console.log(`   - Background: ${nft.combination.background.name}`);
      console.log(`   - Skin: ${nft.combination.skin.name}`);
      console.log(`   - Eyes: ${nft.combination.eyes.name}`);
      console.log(`   - Artifact: ${nft.combination.artifact.name}`);
      console.log(`   - Aura: ${nft.combination.aura.name}`);
      console.log(`   - Image: ${nft.imagePath}`);
      console.log(`   - Metadata: ${nft.metadataPath}`);
    });
    
    console.log('\n🎉 NFT generation completed!');
    console.log('📂 Check the public/nfts/ directory for generated files');
    
  } catch (error) {
    console.error('❌ NFT generation failed:', error);
  }
}

// Запускаем скрипт если он вызван напрямую
if (require.main === module) {
  generateSampleNFTs();
}

module.exports = generateSampleNFTs; 