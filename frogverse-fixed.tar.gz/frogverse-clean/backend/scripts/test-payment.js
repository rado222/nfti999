const TelegramBot = require('node-telegram-bot-api');

// Загружаем переменные окружения
require('dotenv').config();

const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: false });

async function testPayment() {
  try {
    console.log('🧪 Тестирование платежной системы...');
    
    // Проверяем токены
    if (!process.env.TELEGRAM_BOT_TOKEN) {
      console.error('❌ TELEGRAM_BOT_TOKEN не установлен');
      return;
    }
    
    if (!process.env.PAYMENT_PROVIDER_TOKEN) {
      console.error('❌ PAYMENT_PROVIDER_TOKEN не установлен');
      return;
    }
    
    console.log('✅ Токены настроены');
    
    // Получаем информацию о боте
    const botInfo = await bot.getMe();
    console.log('🤖 Информация о боте:', botInfo);
    
    // Тестируем создание инвойса
    const testPayload = Buffer.from(JSON.stringify({
      userId: 'test_user_123',
      amount: 100,
      timestamp: Date.now(),
      type: 'topup'
    })).toString('base64');
    
    console.log('📦 Тестовый payload:', testPayload);
    
    // Создаем тестовый инвойс
    const invoice = {
      title: 'Тестовое пополнение баланса',
      description: 'Frogverse - тестовый платеж',
      payload: testPayload,
      provider_token: process.env.PAYMENT_PROVIDER_TOKEN,
      currency: 'XTR',
      prices: [{
        label: '100 звезд',
        amount: 10000 // 100 XTR в копейках
      }],
      start_parameter: testPayload
    };
    
    console.log('💳 Инвойс создан:', invoice);
    console.log('✅ Тест завершен успешно!');
    console.log('\n📋 Следующие шаги:');
    console.log('1. Создайте бота через @BotFather');
    console.log('2. Настройте платежи в @BotFather');
    console.log('3. Скопируйте токены в .env файл');
    console.log('4. Запустите сервер: npm run dev');
    
  } catch (error) {
    console.error('❌ Ошибка тестирования:', error.message);
    
    if (error.response) {
      console.error('📡 Ответ API:', error.response.data);
    }
  }
}

// Запускаем тест
testPayment(); 