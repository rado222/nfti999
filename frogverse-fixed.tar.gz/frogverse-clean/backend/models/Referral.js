const mongoose = require('mongoose');

const referralSchema = new mongoose.Schema({
  code: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  referrerId: {
    type: String,
    required: true,
    index: true
  },
  referred: [{
    userId: {
      type: String,
      required: true
    },
    joinedAt: {
      type: Date,
      default: Date.now
    },
    isActive: {
      type: Boolean,
      default: false
    },
    battlesPlayed: {
      type: Number,
      default: 0
    },
    rewardClaimed: {
      type: Boolean,
      default: false
    }
  }],
  totalReferrals: {
    type: Number,
    default: 0
  },
  activeReferrals: {
    type: Number,
    default: 0
  },
  totalRewards: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Метод для добавления нового реферала
referralSchema.methods.addReferred = function(userId) {
  const existing = this.referred.find(ref => ref.userId === userId);
  if (!existing) {
    this.referred.push({ userId });
    this.totalReferrals += 1;
    return this.save();
  }
  return Promise.resolve(this);
};

// Метод для активации реферала (после первого боя)
referralSchema.methods.activateReferred = function(userId) {
  const referred = this.referred.find(ref => ref.userId === userId);
  if (referred && !referred.isActive) {
    referred.isActive = true;
    this.activeReferrals += 1;
    return this.save();
  }
  return Promise.resolve(this);
};

// Метод для начисления награды
referralSchema.methods.claimReward = function(userId) {
  const referred = this.referred.find(ref => ref.userId === userId);
  if (referred && referred.isActive && !referred.rewardClaimed) {
    referred.rewardClaimed = true;
    this.totalRewards += 1;
    return this.save();
  }
  return Promise.resolve(this);
};

module.exports = mongoose.model('Referral', referralSchema); 