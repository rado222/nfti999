# 🚀 Настройка Telegram Bot для Frogverse

## 📋 Пошаговая инструкция

### 1. Создание бота через @BotFather

1. **Откройте Telegram** и найдите [@BotFather](https://t.me/botfather)
2. **Отправьте команду** `/newbot`
3. **Введите название бота**: `Frogverse Game Bot`
4. **Введите username бота**: `frogverse_game_bot` (должен заканчиваться на `_bot`)
5. **Сохраните токен бота** - он понадобится для настройки

### 2. Настройка платежей

#### Включение платежей:
1. Отправьте @BotFather команду `/mybots`
2. Выберите созданного бота
3. Нажмите "Payments"
4. Выберите провайдера: "Telegram Stars (XTR)"
5. Получите Payment Provider Token

#### Альтернативные провайдеры:
- **Telegram Stars (XTR)** - для Telegram Stars
- **Stripe** - для карт
- **CryptoBot** - для криптовалют

### 3. Настройка команд бота

Отправьте @BotFather следующие команды:

```
/setcommands
```

Выберите бота и отправьте:

```
start - Запустить игру Frogverse
balance - Проверить баланс
buy - Купить звезды
premium - Premium подписка
help - Помощь
```

### 4. Настройка переменных окружения

Создайте файл `.env` в папке `backend`:

```env
# Telegram Bot
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_BOT_USERNAME=frogverse_game_bot

# Платежи
PAYMENT_PROVIDER_TOKEN=your_payment_provider_token

# MongoDB
MONGODB_URI=mongodb://localhost:27017/frogverse
# или для MongoDB Atlas:
# MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/frogverse

# Порт сервера
PORT=3001
```

### 5. Обновление кода

Замените в `App.jsx`:
```javascript
telegramWebApp.showInvoice(
  `https://t.me/frogverse_game_bot?start=${payload}`, // ← Твой username
  (status) => { /* обработка */ }
);
```

### 6. Тестирование

1. **Запустите бота** локально или на сервере
2. **Отправьте команду** `/start` боту
3. **Нажмите кнопку** "Играть в Frogverse"
4. **Проверьте** открытие Mini App
5. **Попробуйте** пополнить баланс
6. **Проверьте** уведомления

### 7. Деплой

#### Vercel:
```bash
npm run build
vercel --prod
```

#### Railway:
```bash
railway up
```

### 8. Настройка Webhook (для продакшена)

```bash
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://your-domain.com/api/telegram/webhook"}'
```

### 9. Мониторинг

- **Логи бота**: `backend/server.log`
- **Платежи**: Telegram Bot API
- **Ошибки**: консоль браузера

### 10. Безопасность

- **Никогда не коммить токены в git**
- **Используйте HTTPS в продакшене**
- **Валидируйте все платежи на сервере**
- **Логируйте все транзакции**

## 🔧 Полезные команды BotFather

```
/mybots - Список ваших ботов
/botfather - Помощь по BotFather
/setdescription - Изменить описание бота
/setabouttext - Изменить информацию о боте
/setuserpic - Изменить фото бота
/setcommands - Настроить команды
/setmenubutton - Настроить кнопку меню
/deletebot - Удалить бота
```

## 🐛 Устранение неполадок

### Проблема: Mini App не открывается
- Проверьте URL в BotFather
- Убедитесь, что домен поддерживает HTTPS
- Проверьте настройки CORS

### Проблема: Данные пользователя не передаются
- Проверьте токен бота
- Убедитесь, что бот добавлен в чат
- Проверьте настройки WebApp

### Проблема: Реферальная система не работает
- Проверьте обработку команды `/start`
- Убедитесь, что MongoDB подключена
- Проверьте API маршруты

## 📞 Поддержка

Если у вас есть вопросы:
- Создайте Issue в GitHub
- Напишите в Telegram: @your_support_username
- Обратитесь к документации Telegram Bot API

---

**Удачной настройки! 🐸✨** 