# 🚀 Быстрый старт Frogverse

## 1. Создание Telegram Bot

### Через @BotFather:
1. Открой [@BotFather](https://t.me/botfather)
2. Отправь `/newbot`
3. Название: `Frogverse Game Bot`
4. Username: `frogverse_game_bot`
5. **Сохрани токен!** (выглядит как `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`)

### Настройка платежей:
1. Отправь `/mybots`
2. Выбери созданного бота
3. Нажми "Payments"
4. Выбери "Telegram Stars (XTR)"
5. **Сохрани Payment Provider Token!**

## 2. Настройка проекта

### Обнови .env файл:
```bash
cd backend
nano .env
```

Замени содержимое на:
```env
TELEGRAM_BOT_TOKEN=твой_токен_бота
TELEGRAM_BOT_USERNAME=frogverse_game_bot
PAYMENT_PROVIDER_TOKEN=твой_payment_token
MONGODB_URI=mongodb://localhost:27017/frogverse
PORT=3001
NODE_ENV=development
```

## 3. Запуск

### Установка зависимостей:
```bash
npm install
```

### Запуск сервера:
```bash
# В папке frogverse
npm run dev
```

### Тестирование платежей:
```bash
cd backend
npm run test-payment
```

## 4. Проверка работы

1. Открой http://localhost:3002
2. Проверь что игра загружается
3. Перейди в профиль
4. Попробуй пополнить баланс

## 5. Деплой на Vercel

1. Подключи GitHub к Vercel
2. Настрой переменные окружения в Vercel Dashboard
3. Деплой автоматически запустится
4. Обнови URL в BotFather на новый домен

## 🆘 Если что-то не работает

### Черный экран:
- Проверь консоль браузера (F12)
- Убедись что порты не заняты

### Ошибки платежей:
- Проверь токены в .env
- Убедись что бот создан правильно
- Проверь логи сервера

### MongoDB ошибки:
- Установи MongoDB: `brew install mongodb-community`
- Запусти: `brew services start mongodb-community`

## 📱 Использование

1. Открой бота в Telegram
2. Нажми "Играть в Frogverse"
3. Сражайся лягушками
4. Играй в слот-машину
5. Пополняй баланс через профиль

## 🎮 Функции

- ✅ Битвы лягушек
- ✅ Слот-машина
- ✅ Система рефералов
- ✅ Платежи через Telegram Stars
- ✅ NFT коллекция
- ✅ Игра "Граббер"

## 📚 Документация

- [Настройка платежей](PAYMENT_SETUP.md)
- [Настройка Telegram Bot](TELEGRAM_SETUP.md)
- [API документация](API.md) 